/* global React, Icon, UI, SAMPLE */
const { useState: useS7 } = React;

// === Incoming call modal (overlay) ===
const IncomingCall = ({ onAccept, onDismiss }) => (
  <div style={{
    position:'fixed', inset:0, background:'rgba(14,27,44,0.6)', backdropFilter:'blur(6px)',
    display:'grid', placeItems:'center', zIndex: 90,
  }}>
    <div style={{width: 380, background:'var(--surface)', borderRadius:18, boxShadow:'var(--shadow-lg)', overflow:'hidden'}}>
      <div style={{padding:'26px 24px 18px', textAlign:'center', background:'linear-gradient(180deg, var(--ec-orange-50) 0%, var(--surface) 100%)'}}>
        <div className="pill orange" style={{margin:'0 auto 14px', display:'inline-flex'}}>
          <span className="rec-dot" style={{background:'var(--ec-orange)'}}/> Incoming call
        </div>
        <div className={"av xl tone-1"} style={{margin:'0 auto 12px', animation:'pulse-ring 1.6s infinite'}}>MH</div>
        <div style={{fontSize:20, fontWeight:600}}>Marcus Holloway</div>
        <div className="soft mono" style={{fontSize:13, marginTop:4}}>+1 (513) 904-6808</div>
        <div className="soft" style={{fontSize:12, marginTop:8, display:'flex', alignItems:'center', justifyContent:'center', gap:6}}>
          <Icon name="phoneIn" size={12}/> Calling Driver Hotline · Premier Trucking
        </div>
      </div>
      <div style={{padding:'14px 16px 18px', display:'flex', gap:10, justifyContent:'center'}}>
        <button className="btn red" style={{padding:'12px 20px', borderRadius:999}} onClick={onDismiss}>
          <Icon name="hangup" size={14}/> Decline
        </button>
        <button className="btn" style={{padding:'12px 16px', borderRadius:999}} onClick={onDismiss}>
          <Icon name="message" size={14}/> Reply with text
        </button>
        <button className="btn green" style={{padding:'12px 22px', borderRadius:999, fontWeight:600}} onClick={onAccept}>
          <Icon name="phone" size={14}/> Answer
        </button>
      </div>
    </div>
  </div>
);

// === Sign-in screen ===
const SignIn = ({ onSignIn, onBack }) => (
  <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', height:'100vh', background:'var(--surface)', position:'relative'}}>
    {onBack && (
      <button onClick={onBack} className="btn" style={{
        position:'absolute', top:18, left:18, zIndex:5,
        display:'inline-flex', alignItems:'center', gap:6,
      }}>
        <Icon name="back" size={13}/> Back to app
      </button>
    )}
    <div style={{padding:'48px 60px', display:'flex', flexDirection:'column', justifyContent:'center', maxWidth:480, margin:'0 auto', width:'100%'}}>
      <div style={{display:'flex', alignItems:'center', gap:12, marginBottom:48}}>
        <div className="brand-mark" style={{width:40, height:40, borderRadius:11}}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
            <circle cx="12" cy="12" r="9"/>
            <circle cx="12" cy="12" r="3" fill="currentColor"/>
          </svg>
        </div>
        <div>
          <div style={{fontWeight:700, fontSize:18}}>Easy Call</div>
          <div className="soft" style={{fontSize:12}}>Multi-account workspace</div>
        </div>
      </div>
      <h1 style={{fontSize:30, fontWeight:600, letterSpacing:'-0.02em', margin:'0 0 8px'}}>Welcome back.</h1>
      <p className="muted" style={{margin:'0 0 32px', fontSize:14.5, lineHeight:1.6}}>
        Sign in to manage every line, every account, in one tab.
      </p>
      <div className="field" style={{marginBottom:14}}>
        <div className="label">Email</div>
        <input className="input" defaultValue="eld@premiertruckinggroup.com"/>
      </div>
      <div className="field" style={{marginBottom:8}}>
        <div className="label">Password</div>
        <input className="input" type="password" defaultValue="••••••••"/>
      </div>
      <div style={{display:'flex', alignItems:'center', marginBottom:24}}>
        <label style={{display:'flex', gap:6, fontSize:12.5, color:'var(--text-muted)'}}>
          <input type="checkbox" defaultChecked/> Keep me signed in
        </label>
        <div className="spacer"/>
        <a style={{fontSize:12.5, color:'var(--ec-orange-600)', textDecoration:'none', fontWeight:500}}>Forgot password?</a>
      </div>
      <button className="btn primary" style={{padding:'12px', fontSize:14, fontWeight:600}} onClick={onSignIn}>Sign in</button>
      <div style={{display:'flex', alignItems:'center', gap:10, margin:'24px 0', color:'var(--text-soft)', fontSize:11.5}}>
        <div style={{flex:1, height:1, background:'var(--border)'}}/>or<div style={{flex:1, height:1, background:'var(--border)'}}/>
      </div>
      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:8}}>
        <button className="btn"><Icon name="globe" size={13}/> SSO (SAML)</button>
        <button className="btn"><Icon name="mail" size={13}/> Magic link</button>
      </div>
      <div className="soft" style={{fontSize:11.5, marginTop:36, textAlign:'center'}}>
        New to Easy Call? <a style={{color:'var(--ec-orange-600)', fontWeight:500}}>Start a free trial</a> · Need help? <a style={{color:'var(--ec-orange-600)', fontWeight:500}}>Talk to sales</a>
      </div>
    </div>
    <div style={{
      background:'linear-gradient(135deg, #F25C1F 0%, #C13F0A 100%)',
      color:'white', padding:'48px', display:'flex', flexDirection:'column', justifyContent:'flex-end',
      position:'relative', overflow:'hidden',
    }}>
      <div style={{position:'absolute', top:-80, right:-80, width:480, height:480, borderRadius:'50%', background:'rgba(255,255,255,0.08)'}}/>
      <div style={{position:'absolute', top:120, right:80, width:280, height:280, borderRadius:'50%', background:'rgba(255,255,255,0.06)'}}/>
      <div style={{position:'absolute', top:60, left:60, fontSize:11, color:'rgba(255,255,255,0.7)', letterSpacing:'0.2em', textTransform:'uppercase', fontWeight:600}}>An all-in-one business phone</div>

      <div style={{position:'relative', zIndex:1, maxWidth:540}}>
        <div style={{display:'inline-flex', alignItems:'center', gap:8, padding:'6px 12px', background:'rgba(255,255,255,0.18)', borderRadius:999, fontSize:12.5, marginBottom:24}}>
          <span className="dot green"/> Unlimited accounts · Unlimited numbers · One dashboard
        </div>
        <h2 style={{fontSize:36, fontWeight:600, lineHeight:1.15, letterSpacing:'-0.02em', margin:'0 0 16px'}}>
          Every line, every account,<br/>in a single browser tab.
        </h2>
        <p style={{fontSize:15, lineHeight:1.65, color:'rgba(255,255,255,0.88)', maxWidth:460, margin:'0 0 36px'}}>
          Receive incoming calls from any of your business numbers, see exactly which line was dialed, and place outbound calls from any of them — all over WebRTC, no desk phone needed.
        </p>
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, fontSize:13}}>
          {[
            ['Live transcription', 'sparkle'],
            ['Smart voicemail', 'voicemail'],
            ['SMS + team chat', 'message'],
            ['IVR & queues', 'routing'],
            ['CRM sync', 'integrations'],
            ['Cross-account analytics', 'analytics'],
          ].map(([t, i]) => (
            <div key={t} style={{display:'flex', alignItems:'center', gap:8, padding:'8px 0'}}>
              <Icon name={i} size={14}/> {t}
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

window.IncomingCall = IncomingCall;
window.SignIn = SignIn;
