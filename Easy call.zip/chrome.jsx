/* global React, Icon, SAMPLE */
const { useState } = React;

// Initials helper
const initials = (n) => n.split(' ').map(s => s[0]).filter(Boolean).slice(0,2).join('').toUpperCase();
const toneFor = (s) => 'tone-' + (((s||'').charCodeAt(0) % 7) + 1);

// === Sidebar / Rail ===
const NAV_GROUPS = [
  { label: 'Communicate', items: [
    { id: 'phone',     name: 'Phone',          icon: 'phone',    badge: null },
    { id: 'history',   name: 'Call history',   icon: 'history',  badge: null },
    { id: 'voicemail', name: 'Voicemail',      icon: 'voicemail',badge: 2 },
    { id: 'messages',  name: 'Messages',       icon: 'message',  badge: 9 },
    { id: 'contacts',  name: 'Contacts',       icon: 'contacts', badge: null },
  ]},
  { label: 'Manage', items: [
    { id: 'numbers',   name: 'Numbers',        icon: 'number',   badge: null },
  ]},
  { label: 'Configure', items: [
    { id: 'settings',  name: 'Settings',       icon: 'settings', badge: null },
  ]},
];

const Rail = ({ active, onNav, collapsed, onToggle, accounts }) => {
  const connected = accounts.filter(a => a.status === 'connected').length;
  return (
    <aside className="rail">
      <div className="rail-head">
        <div className="brand-mark">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
            <circle cx="12" cy="12" r="9"/>
            <circle cx="12" cy="12" r="3" fill="currentColor"/>
          </svg>
        </div>
        <div className="brand-text">
          <div className="brand-name">Easy Call</div>
          <div className="brand-sub">Multi-account workspace</div>
        </div>
        {!collapsed && (
          <button className="btn ghost icon" onClick={onToggle} title="Collapse sidebar" style={{marginLeft:'auto'}}>
            <Icon name="back" size={14}/>
          </button>
        )}
      </div>
      {collapsed && (
        <button className="btn ghost icon rail-expand" onClick={onToggle} title="Expand sidebar">
          <Icon name="chevRight" size={14}/>
        </button>
      )}
      <nav className="nav">
        {NAV_GROUPS.map(group => (
          <React.Fragment key={group.label}>
            <div className="nav-section-label">{group.label}</div>
            {group.items.map(it => (
              <button key={it.id} className={"nav-item" + (active === it.id ? ' active' : '')} onClick={() => onNav(it.id)} title={it.name}>
                <Icon name={it.icon} className="nav-icon"/>
                <span className="nav-label">{it.name}</span>
                {it.badge && <span className="nav-badge">{it.badge}</span>}
              </button>
            ))}
          </React.Fragment>
        ))}
      </nav>
      <div className="rail-foot">
        <div className="avatar">EC</div>
        <div className="rail-foot-detail">
          <div className="rail-foot-name">Eldon Cole</div>
          <div className="rail-foot-meta">{connected}/{accounts.length} accounts connected</div>
        </div>
      </div>
    </aside>
  );
};

// === Topbar ===
const Topbar = ({ title, subtitle, accountFilter, onAccountFilter, accounts, right }) => (
  <header className="topbar">
    <div className="topbar-title">
      <h1>{title}</h1>
      {subtitle && <div className="page-sub topbar-sub">{subtitle}</div>}
    </div>
    <div className="topbar-spacer"/>
    <div className="search-wrap">
      <Icon name="search" size={14}/>
      <input className="search" placeholder="Search numbers, contacts, recordings…"/>
    </div>
    <select className="select topbar-select" value={accountFilter} onChange={e => onAccountFilter(e.target.value)}>
      <option value="all">All accounts ({accounts.length})</option>
      {accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
    </select>
    <button className="btn ghost icon" title="Notifications"><Icon name="bell" size={16}/></button>
    {right}
    <button className="btn primary sm">
      <Icon name="add" size={14}/> New call
    </button>
  </header>
);

// Status chip used a lot
const StatusChip = ({ status }) => {
  const map = {
    connected:  { c: 'green',  label: 'Connected',  dot: 'green' },
    syncing:    { c: 'amber',  label: 'Syncing',    dot: 'amber' },
    error:      { c: 'red',    label: 'Reconnect',  dot: 'red'   },
    active:     { c: 'green',  label: 'Active',     dot: 'green' },
    porting:    { c: 'amber',  label: 'Porting',    dot: 'amber' },
    paused:     { c: 'slate',  label: 'Paused',     dot: 'gray'  },
    completed:  { c: 'slate',  label: 'Completed',  dot: 'gray'  },
    missed:     { c: 'red',    label: 'Missed',     dot: 'red'   },
    'no-answer':{ c: 'amber',  label: 'No answer',  dot: 'amber' },
    available:  { c: 'slate',  label: 'Available',  dot: 'gray'  },
    configured: { c: 'green',  label: 'Configured', dot: 'green' },
  };
  const m = map[status] || { c: 'slate', label: status, dot: 'gray' };
  return <span className={"pill " + m.c}><span className={"dot " + m.dot}/> {m.label}</span>;
};

window.UI = { Rail, Topbar, StatusChip, initials, toneFor };
