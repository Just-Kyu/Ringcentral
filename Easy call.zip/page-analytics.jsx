/* global React, Icon, UI, SAMPLE */
const { useState: useS6 } = React;

// === Analytics ===
const AnalyticsPage = () => {
  const [range, setRange] = useS6('7d');
  return (
    <div className="page">
      <div className="page-head">
        <div style={{flex:1}}>
          <h2 className="page-title">Analytics</h2>
          <div className="page-sub">Cross-account performance · last 7 days</div>
        </div>
        <div style={{display:'flex', gap:6, background:'var(--surface-2)', border:'1px solid var(--border)', borderRadius:8, padding:3}}>
          {['24h','7d','30d','90d'].map(r => (
            <button key={r} className={"btn sm " + (r === range ? 'dark' : 'ghost')} onClick={() => setRange(r)} style={{padding:'4px 10px'}}>{r}</button>
          ))}
        </div>
        <button className="btn"><Icon name="download" size={13}/> Export</button>
      </div>

      <div className="grid" style={{gridTemplateColumns:'repeat(4, 1fr)', gap:16, marginBottom:16}}>
        <Kpi label="Total calls" v="1,847" delta="+12.4%" trend="up"/>
        <Kpi label="Avg. duration" v="3:48" delta="+0:14" trend="up"/>
        <Kpi label="Missed rate" v="6.2%" delta="−1.8%" trend="down"/>
        <Kpi label="Service level" v="94%" delta="+2%" trend="up" sub="Answered <30s"/>
      </div>

      <div className="grid" style={{gridTemplateColumns:'2fr 1fr', gap:16, marginBottom:16}}>
        <div className="card">
          <div className="card-head">
            <div className="card-title">Call volume</div>
            <div className="spacer"/>
            <span className="pill"><span className="dot" style={{background:'var(--ec-orange)'}}/> Inbound</span>
            <span className="pill"><span className="dot" style={{background:'var(--ec-slate-700)'}}/> Outbound</span>
          </div>
          <div className="card-body">
            <BarChart/>
          </div>
        </div>
        <div className="card">
          <div className="card-head"><div className="card-title">Top numbers</div></div>
          <div>
            {SAMPLE.NUMBERS.slice(0,5).map((n, i) => {
              const w = [92, 71, 58, 41, 28][i];
              return (
                <div key={n.id} style={{padding:'10px 16px', borderBottom:'1px solid var(--border)'}}>
                  <div style={{display:'flex', alignItems:'baseline', gap:8, marginBottom:4}}>
                    <div style={{fontSize:13, fontWeight:500}}>{n.label}</div>
                    <div className="soft mono" style={{fontSize:11}}>{n.number}</div>
                    <div className="spacer"/>
                    <div className="mono" style={{fontSize:13, fontWeight:600}}>{[412, 318, 261, 184, 122][i]}</div>
                  </div>
                  <div style={{height:6, background:'var(--surface-2)', borderRadius:3, overflow:'hidden'}}>
                    <div style={{width: w+'%', height:'100%', background:'var(--ec-orange)'}}/>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns:'1fr 1fr 1fr', gap:16}}>
        <div className="card">
          <div className="card-head"><div className="card-title">Queue performance</div></div>
          <div className="card-body col" style={{gap:14}}>
            {SAMPLE.RING_GROUPS.map((g, i) => (
              <div key={g.id}>
                <div style={{display:'flex', alignItems:'baseline', gap:6, marginBottom:6}}>
                  <div style={{fontSize:13, fontWeight:500}}>{g.name}</div>
                  <div className="spacer"/>
                  <div className="mono soft" style={{fontSize:11}}>SLA {[96,89,93,82][i]}%</div>
                </div>
                <div style={{height:6, background:'var(--surface-2)', borderRadius:3, overflow:'hidden'}}>
                  <div style={{width: [96,89,93,82][i]+'%', height:'100%', background: [96,89,93,82][i] >= 90 ? 'var(--green)' : 'var(--amber)'}}/>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-head"><div className="card-title">Agent leaderboard</div></div>
          <div>
            {[
              {n:'Priya Raman', c: 184, d:'4:21'},
              {n:'Beatrice Yoon', c: 162, d:'2:48'},
              {n:'Eldon Cole',   c: 141, d:'5:02'},
              {n:'Owen Bradshaw', c: 98, d:'3:14'},
            ].map((a, i) => (
              <div key={a.n} style={{display:'flex', alignItems:'center', gap:10, padding:'10px 16px', borderBottom:'1px solid var(--border)'}}>
                <div style={{width:18, fontSize:11, fontWeight:600, color:'var(--text-soft)'}}>{i+1}</div>
                <div className={"av sm " + UI.toneFor(a.n)}>{UI.initials(a.n)}</div>
                <div style={{flex:1, fontSize:13}}>{a.n}</div>
                <div className="mono" style={{fontSize:12.5, fontWeight:600}}>{a.c}</div>
                <div className="soft mono" style={{fontSize:11}}>{a.d}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <Icon name="sparkle" size={13}/>
            <div className="card-title">AI sentiment</div>
            <span className="pill orange" style={{marginLeft:6}}>Beta</span>
          </div>
          <div className="card-body col" style={{gap:14}}>
            <SentimentRow label="Positive" pct={62} color="var(--green)"/>
            <SentimentRow label="Neutral" pct={28} color="var(--ec-slate-500)"/>
            <SentimentRow label="Negative" pct={10} color="var(--red)"/>
            <div className="hr"/>
            <div className="muted" style={{fontSize:12.5, lineHeight:1.5}}>
              <strong>Coaching insight:</strong> 7 calls flagged for long hold times (&gt;90s) on the Sales queue this week.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Kpi = ({ label, v, delta, trend, sub }) => (
  <div className="card">
    <div className="card-body">
      <div className="soft" style={{fontSize:11, textTransform:'uppercase', letterSpacing:'0.06em', fontWeight:600}}>{label}</div>
      <div style={{fontSize:28, fontWeight:600, marginTop:6, fontFamily:'var(--font-mono)', letterSpacing:'-0.01em'}}>{v}</div>
      <div style={{display:'flex', alignItems:'center', gap:6, marginTop:4}}>
        <span className={"pill " + (trend === 'up' ? 'green' : 'green')} style={{fontSize:11}}>
          <Icon name={trend === 'up' ? 'arrowUp' : 'arrowDown'} size={10}/> {delta}
        </span>
        {sub && <span className="soft" style={{fontSize:11}}>{sub}</span>}
      </div>
    </div>
  </div>
);

const BarChart = () => {
  const days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  const inb = [184, 212, 198, 248, 261, 102, 64];
  const out = [142, 168, 156, 178, 192, 78, 41];
  const max = Math.max(...inb, ...out);
  return (
    <div style={{display:'flex', alignItems:'flex-end', height:220, gap:18, paddingBottom:24, position:'relative'}}>
      {days.map((d, i) => (
        <div key={d} style={{flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:4, position:'relative'}}>
          <div style={{display:'flex', gap:4, alignItems:'flex-end', height:'100%'}}>
            <div style={{width:14, height: (inb[i]/max)*180, background:'var(--ec-orange)', borderRadius:'4px 4px 0 0'}}/>
            <div style={{width:14, height: (out[i]/max)*180, background:'var(--ec-slate-700)', borderRadius:'4px 4px 0 0'}}/>
          </div>
          <div className="soft" style={{fontSize:11, position:'absolute', bottom:0}}>{d}</div>
        </div>
      ))}
    </div>
  );
};

const SentimentRow = ({ label, pct, color }) => (
  <div>
    <div style={{display:'flex', alignItems:'baseline', gap:6, marginBottom:5}}>
      <div style={{fontSize:13}}>{label}</div>
      <div className="spacer"/>
      <div className="mono" style={{fontSize:13, fontWeight:600}}>{pct}%</div>
    </div>
    <div style={{height:8, background:'var(--surface-2)', borderRadius:4, overflow:'hidden'}}>
      <div style={{width: pct+'%', height:'100%', background: color}}/>
    </div>
  </div>
);

// === Integrations ===
const IntegrationsPage = () => {
  const grouped = SAMPLE.INTEGRATIONS.reduce((acc, x) => { (acc[x.cat] = acc[x.cat] || []).push(x); return acc; }, {});
  return (
    <div className="page">
      <div className="page-head">
        <div style={{flex:1}}>
          <h2 className="page-title">Integrations</h2>
          <div className="page-sub">Connect Easy Call to your CRM, calendar, and other tools</div>
        </div>
        <button className="btn"><Icon name="link" size={13}/> Browse marketplace</button>
        <button className="btn primary"><Icon name="add" size={14}/> Custom webhook</button>
      </div>

      {Object.keys(grouped).map(cat => (
        <div key={cat} style={{marginBottom:20}}>
          <div className="label" style={{marginBottom:10}}>{cat}</div>
          <div className="grid" style={{gridTemplateColumns:'repeat(3, 1fr)', gap:14}}>
            {grouped[cat].map(it => (
              <div key={it.id} className="card">
                <div className="card-body" style={{display:'flex', flexDirection:'column', gap:10}}>
                  <div style={{display:'flex', alignItems:'flex-start', gap:12}}>
                    <div style={{width:40, height:40, borderRadius:10, background:'var(--surface-2)', border:'1px solid var(--border)', display:'grid', placeItems:'center', fontWeight:700, color:'var(--ec-orange-600)', fontSize:15}}>
                      {it.name[0]}
                    </div>
                    <div style={{flex:1, minWidth:0}}>
                      <div style={{fontSize:14, fontWeight:600}}>{it.name}</div>
                      <div className="soft" style={{fontSize:11.5}}>{it.cat}</div>
                    </div>
                    <UI.StatusChip status={it.status}/>
                  </div>
                  <div className="soft" style={{fontSize:11.5}}>
                    {it.status === 'connected' || it.status === 'configured'
                      ? <>Connected by <strong>{it.by}</strong> on {it.when}</>
                      : <>Sync calls, contacts, and recordings automatically.</>}
                  </div>
                  <div style={{display:'flex', gap:6}}>
                    {(it.status === 'connected' || it.status === 'configured')
                      ? <><button className="btn sm" style={{flex:1}}><Icon name="settings" size={12}/> Configure</button><button className="btn sm ghost"><Icon name="more" size={13}/></button></>
                      : <button className="btn sm primary" style={{flex:1}}>Connect</button>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

// === Admin & Billing ===
const BillingPage = () => (
  <div className="page">
    <div className="page-head">
      <div style={{flex:1}}>
        <h2 className="page-title">Admin & billing</h2>
        <div className="page-sub">Plans, users, accounts, and invoices</div>
      </div>
      <button className="btn"><Icon name="download" size={13}/> Export invoices</button>
      <button className="btn primary"><Icon name="userPlus" size={14}/> Invite user</button>
    </div>

    <div className="grid" style={{gridTemplateColumns:'2fr 1fr', gap:16, marginBottom:16}}>
      <div className="card">
        <div className="card-head">
          <Icon name="briefcase" size={14}/>
          <div className="card-title">Connected accounts</div>
          <div className="spacer"/>
          <button className="btn sm ghost"><Icon name="add" size={12}/> Add account</button>
        </div>
        <table>
          <thead><tr><th>Account</th><th>Plan</th><th>Numbers</th><th>Owner email</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {SAMPLE.ACCOUNTS.map(a => (
              <tr key={a.id}>
                <td><div style={{fontWeight:500}}>{a.name}</div></td>
                <td><span className="pill slate">{a.plan}</span></td>
                <td className="mono">{a.numbers}</td>
                <td className="muted">{a.email}</td>
                <td><UI.StatusChip status={a.status}/></td>
                <td><button className="btn ghost icon"><Icon name="more" size={14}/></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card">
        <div className="card-head">
          <Icon name="billing" size={14}/>
          <div className="card-title">Current cycle</div>
        </div>
        <div className="card-body col" style={{gap:14}}>
          <div>
            <div className="soft" style={{fontSize:11, textTransform:'uppercase', letterSpacing:'0.06em', fontWeight:600}}>Total this month</div>
            <div style={{fontSize:32, fontWeight:600, fontFamily:'var(--font-mono)', marginTop:4}}>$324.18</div>
            <div className="soft" style={{fontSize:12}}>Closes May 1, 2026</div>
          </div>
          <div className="hr"/>
          <KVRow3 k="Seat licenses (8 × $24.99)" v="$199.92"/>
          <KVRow3 k="Number rentals (16)" v="$56.00"/>
          <KVRow3 k="Outbound minutes" v="$48.32"/>
          <KVRow3 k="SMS (A2P)" v="$19.94"/>
          <div className="hr"/>
          <button className="btn primary" style={{width:'100%'}}>Manage subscription</button>
        </div>
      </div>
    </div>

    <div className="card">
      <div className="card-head">
        <Icon name="team" size={14}/>
        <div className="card-title">Users & permissions</div>
        <div className="spacer"/>
        <div className="search-wrap" style={{width:240}}>
          <Icon name="search" size={13}/>
          <input className="search" placeholder="Search users" style={{width:'100%'}}/>
        </div>
      </div>
      <table>
        <thead><tr><th>User</th><th>Role</th><th>Account access</th><th>Extension</th><th>Last active</th><th>2FA</th><th></th></tr></thead>
        <tbody>
          {[
            {n:'Eldon Cole',       r:'Owner',        a:'All accounts',         x:'4001', l:'Now',        f:true},
            {n:'Priya Raman',      r:'Admin',        a:'Premier Trucking',     x:'4101', l:'2m ago',     f:true},
            {n:'Aniya Whitfield',  r:'Admin',        a:'Cascade Logistics',    x:'4201', l:'14m ago',    f:true},
            {n:'Beatrice Yoon',    r:'Agent',        a:'Premier Trucking',     x:'4100', l:'1h ago',     f:false},
            {n:'Marcus Holloway',  r:'Driver',       a:'Premier Trucking',     x:'—',    l:'Yesterday',  f:false},
            {n:'Owen Bradshaw',    r:'Driver',       a:'Premier Trucking',     x:'—',    l:'3d ago',     f:false},
          ].map(u => (
            <tr key={u.n}>
              <td><div style={{display:'flex', gap:10, alignItems:'center'}}><div className={"av sm " + UI.toneFor(u.n)}>{UI.initials(u.n)}</div><div style={{fontWeight:500}}>{u.n}</div></div></td>
              <td><span className={"pill " + (u.r === 'Owner' ? 'orange' : u.r === 'Admin' ? 'slate' : 'slate')}>{u.r}</span></td>
              <td className="muted">{u.a}</td>
              <td className="mono">{u.x}</td>
              <td className="muted">{u.l}</td>
              <td>{u.f ? <Icon name="check" size={14} style={{color:'var(--green)'}}/> : <span className="soft">Off</span>}</td>
              <td><button className="btn ghost icon"><Icon name="more" size={14}/></button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

const KVRow3 = ({ k, v }) => (
  <div style={{display:'flex'}}>
    <div className="muted" style={{flex:1, fontSize:13}}>{k}</div>
    <div className="mono" style={{fontSize:13, fontWeight:500}}>{v}</div>
  </div>
);

// === Settings (light, but exists) ===
const SettingsPage = () => (
  <div className="page" style={{maxWidth:780}}>
    <div className="page-head">
      <div style={{flex:1}}>
        <h2 className="page-title">Settings</h2>
        <div className="page-sub">Personal preferences and device setup</div>
      </div>
    </div>
    <div className="card" style={{marginBottom:16}}>
      <div className="card-head"><div className="card-title">Audio devices</div></div>
      <div className="card-body col" style={{gap:14}}>
        <div className="field"><div className="label">Microphone</div><select className="select"><option>MacBook Pro Microphone</option><option>Jabra Evolve 75</option></select></div>
        <div className="field"><div className="label">Speakers</div><select className="select"><option>MacBook Pro Speakers</option><option>Jabra Evolve 75</option></select></div>
        <div className="field"><div className="label">Ringer device</div><select className="select"><option>Both speakers</option><option>Headset only</option></select></div>
      </div>
    </div>
    <div className="card" style={{marginBottom:16}}>
      <div className="card-head"><div className="card-title">Call handling</div></div>
      <div className="card-body col" style={{gap:14}}>
        <Toggle label="Auto-record outbound calls" desc="Stored 90 days · Premier Trucking only" on/>
        <Toggle label="Live AI transcription" desc="Real-time captions during calls" on/>
        <Toggle label="Auto-summary after calls" desc="Action items emailed to you" on/>
        <Toggle label="Voicemail-to-email" desc="MP3 + transcript to eld@premiertruckinggroup.com" on/>
        <Toggle label="Block likely spam" desc="Powered by carrier reputation"/>
      </div>
    </div>
    <div className="card">
      <div className="card-head"><div className="card-title">Notifications</div></div>
      <div className="card-body col" style={{gap:14}}>
        <Toggle label="Desktop notifications" on/>
        <Toggle label="Missed-call email digest" on/>
        <Toggle label="Mobile push (iOS)" on/>
      </div>
    </div>
  </div>
);

const Toggle = ({ label, desc, on }) => {
  const [v, setV] = useS6(!!on);
  return (
    <div style={{display:'flex', alignItems:'center', gap:14}}>
      <div style={{flex:1}}>
        <div style={{fontSize:13.5, fontWeight:500}}>{label}</div>
        {desc && <div className="soft" style={{fontSize:12}}>{desc}</div>}
      </div>
      <button onClick={() => setV(!v)} style={{
        width:38, height:22, borderRadius:11, border:'none',
        background: v ? 'var(--ec-orange)' : 'var(--surface-3)',
        position:'relative', cursor:'pointer', padding:0,
      }}>
        <div style={{
          width:18, height:18, borderRadius:'50%', background:'white',
          position:'absolute', top:2, left: v ? 18 : 2, transition:'left 0.15s',
          boxShadow:'0 1px 3px rgba(0,0,0,0.2)',
        }}/>
      </button>
    </div>
  );
};

window.PageAnalytics = AnalyticsPage;
window.PageIntegrations = IntegrationsPage;
window.PageBilling = BillingPage;
window.PageSettings = SettingsPage;
