/* global React, Icon */
// Sample data: accounts, numbers, contacts, calls, voicemails, messages, etc.

const ACCOUNTS = [
  { id: 'a1', name: 'Premier Trucking Group',  email: 'eld@premiertruckinggroup.com', status: 'connected', numbers: 8, plan: 'Business Pro' },
  { id: 'a2', name: 'Cascade Logistics',       email: 'admin@cascadelogistics.io',     status: 'connected', numbers: 4, plan: 'Business Pro' },
  { id: 'a3', name: 'Northwind Dispatch',      email: 'ops@northwinddispatch.com',     status: 'syncing',   numbers: 3, plan: 'Standard'     },
  { id: 'a4', name: 'Beacon Freight Co.',      email: 'beacon@beaconfreight.com',      status: 'error',     numbers: 1, plan: 'Standard'     },
];

const NUMBERS = [
  { id: 'n1', label: 'Main Dispatch',     number: '+1 (513) 776-4064', account: 'Premier Trucking Group', type: 'Local',     status: 'active', sms: true,  fwd: 'Ring group: Dispatch'   },
  { id: 'n2', label: 'Driver Hotline',    number: '+1 (513) 776-2210', account: 'Premier Trucking Group', type: 'Local',     status: 'active', sms: true,  fwd: 'IVR: Driver Support'    },
  { id: 'n3', label: 'After-hours',       number: '+1 (513) 776-9001', account: 'Premier Trucking Group', type: 'Local',     status: 'active', sms: false, fwd: 'Voicemail-only'         },
  { id: 'n4', label: 'Sales',             number: '+1 (888) 412-0090', account: 'Premier Trucking Group', type: 'Toll-free', status: 'active', sms: false, fwd: 'Queue: Sales'           },
  { id: 'n5', label: 'Cascade Main',      number: '+1 (206) 555-0118', account: 'Cascade Logistics',      type: 'Local',     status: 'active', sms: true,  fwd: 'IVR: Main Menu'         },
  { id: 'n6', label: 'Cascade Billing',   number: '+1 (206) 555-0120', account: 'Cascade Logistics',      type: 'Local',     status: 'active', sms: false, fwd: 'User: Marisol Vega'     },
  { id: 'n7', label: 'Northwind Ops',     number: '+1 (503) 555-0241', account: 'Northwind Dispatch',     type: 'Local',     status: 'porting',sms: false, fwd: 'Voicemail-only'         },
  { id: 'n8', label: 'Beacon General',    number: '+1 (404) 555-0167', account: 'Beacon Freight Co.',     type: 'Local',     status: 'paused', sms: true,  fwd: '— none —'               },
];

const CONTACTS = [
  { id: 'c1', name: 'Marcus Holloway',   role: 'Owner-Operator',     org: 'Holloway Hauling',  phone: '+1 (513) 904-6808', email: 'marcus@hollowayhaul.com',     starred: true,  tags: ['Driver','VIP'] },
  { id: 'c2', name: 'Priya Raman',        role: 'Dispatch Lead',     org: 'Premier Trucking',  phone: '+1 (513) 776-2240', email: 'praman@premiertruckinggroup.com', starred: true, tags: ['Internal'] },
  { id: 'c3', name: 'Owen Bradshaw',      role: 'Driver',            org: 'Premier Trucking',  phone: '+1 (614) 555-2241', email: 'owen.b@premiertruckinggroup.com', starred: false, tags: ['Driver'] },
  { id: 'c4', name: 'Sasha Iniguez',      role: 'Account Manager',   org: 'FreightLink',       phone: '+1 (415) 555-1190', email: 'siniguez@freightlink.co',         starred: false, tags: ['Vendor'] },
  { id: 'c5', name: 'Devon Park',         role: 'Broker',            org: 'TrueRoute Brokerage',phone: '+1 (312) 555-0421',email: 'devon@trueroute.io',              starred: true,  tags: ['Broker','VIP'] },
  { id: 'c6', name: 'Yuki Tanaka',        role: 'Compliance Officer',org: 'DOT Compliance Co.',phone: '+1 (415) 555-0903', email: 'yuki@dotcompliance.co',           starred: false, tags: ['Vendor'] },
  { id: 'c7', name: 'Theodore Cole',      role: 'Driver',            org: 'Premier Trucking',  phone: '+1 (614) 555-3022', email: 'tcole@premiertruckinggroup.com',  starred: false, tags: ['Driver'] },
  { id: 'c8', name: 'Aniya Whitfield',    role: 'CFO',               org: 'Cascade Logistics', phone: '+1 (206) 555-0117', email: 'aniya@cascadelogistics.io',       starred: true,  tags: ['Internal','VIP'] },
  { id: 'c9', name: 'Rohan Mehta',        role: 'Customer',          org: 'BlueRidge Produce', phone: '+1 (704) 555-0833', email: 'rohan@blueridgeproduce.com',      starred: false, tags: ['Customer'] },
  { id: 'c10',name: 'Kai Andersen',       role: 'Driver',            org: 'Premier Trucking',  phone: '+1 (614) 555-3088', email: 'kai@premiertruckinggroup.com',     starred: false, tags: ['Driver'] },
  { id: 'c11',name: 'Liana Okafor',       role: 'Insurance Adjuster',org: 'Sentinel Casualty', phone: '+1 (646) 555-7710', email: 'lokafor@sentinelcas.com',         starred: false, tags: ['Vendor'] },
  { id: 'c12',name: 'Beatrice Yoon',      role: 'Receptionist',      org: 'Premier Trucking',  phone: '+1 (513) 776-1100', email: 'byoon@premiertruckinggroup.com',  starred: false, tags: ['Internal'] },
];

const CALLS = [
  { id: 'h1', dir: 'out', to: 'Marcus Holloway',     num: '+1 (513) 904-6808', via: 'Main Dispatch',   account: 'Premier Trucking', dur: '04:12', when: '19m ago',   ts: 1714082460000, recorded: true,  status: 'completed' },
  { id: 'h2', dir: 'in',  to: 'Priya Raman',          num: '+1 (513) 776-2240', via: 'Driver Hotline',  account: 'Premier Trucking', dur: '02:48', when: '42m ago',   ts: 1714080740000, recorded: false, status: 'completed' },
  { id: 'h3', dir: 'in',  to: 'Unknown',              num: '+1 (305) 555-7184', via: 'Sales',           account: 'Premier Trucking', dur: '00:00', when: '1h ago',    ts: 1714079240000, recorded: false, status: 'missed'    },
  { id: 'h4', dir: 'out', to: 'Devon Park',           num: '+1 (312) 555-0421', via: 'Main Dispatch',   account: 'Premier Trucking', dur: '12:03', when: '2h ago',    ts: 1714075000000, recorded: true,  status: 'completed' },
  { id: 'h5', dir: 'in',  to: 'Aniya Whitfield',      num: '+1 (206) 555-0117', via: 'Cascade Main',    account: 'Cascade Logistics', dur: '08:55', when: '3h ago',    ts: 1714071600000, recorded: true,  status: 'completed' },
  { id: 'h6', dir: 'out', to: 'Yuki Tanaka',          num: '+1 (415) 555-0903', via: 'Main Dispatch',   account: 'Premier Trucking', dur: '00:48', when: '4h ago',    ts: 1714068000000, recorded: false, status: 'completed' },
  { id: 'h7', dir: 'in',  to: 'Owen Bradshaw',        num: '+1 (614) 555-2241', via: 'Driver Hotline',  account: 'Premier Trucking', dur: '01:32', when: 'Yesterday', ts: 1713996000000, recorded: true,  status: 'completed' },
  { id: 'h8', dir: 'out', to: 'Sasha Iniguez',        num: '+1 (415) 555-1190', via: 'Sales',           account: 'Premier Trucking', dur: '00:00', when: 'Yesterday', ts: 1713989000000, recorded: false, status: 'no-answer' },
  { id: 'h9', dir: 'in',  to: 'Rohan Mehta',          num: '+1 (704) 555-0833', via: 'Sales',           account: 'Premier Trucking', dur: '06:11', when: 'Yesterday', ts: 1713982000000, recorded: true,  status: 'completed' },
  { id: 'h10',dir: 'in',  to: 'Unknown',              num: '+1 (513) 555-2298', via: 'After-hours',     account: 'Premier Trucking', dur: '00:00', when: 'Tue',       ts: 1713890000000, recorded: false, status: 'missed' },
  { id: 'h11',dir: 'out', to: 'Beatrice Yoon',        num: '+1 (513) 776-1100', via: 'Main Dispatch',   account: 'Premier Trucking', dur: '03:41', when: 'Tue',       ts: 1713884000000, recorded: false, status: 'completed' },
  { id: 'h12',dir: 'in',  to: 'Liana Okafor',         num: '+1 (646) 555-7710', via: 'Driver Hotline',  account: 'Premier Trucking', dur: '14:22', when: 'Mon',       ts: 1713790000000, recorded: true,  status: 'completed' },
];

const VOICEMAILS = [
  { id: 'v1', from: 'Devon Park',          num: '+1 (312) 555-0421', via: 'Sales',          account: 'Premier Trucking', dur: '0:42', when: '23m ago', read: false, transcript: "Hey, it's Devon at TrueRoute. I've got that load out of Cincinnati on Friday — 47k pounds, dry van, picking up at 8 AM. Wanted to confirm you can cover. Give me a ring back when you get a sec.", urgent: true },
  { id: 'v2', from: 'Yuki Tanaka',         num: '+1 (415) 555-0903', via: 'Main Dispatch',  account: 'Premier Trucking', dur: '1:08', when: '2h ago',  read: false, transcript: "Hi, this is Yuki from DOT Compliance. I'm following up on the IFTA filing for Q1. We're missing fuel receipts for two of your trucks — unit 4471 and 4519. Can you send those over today? My direct line is 415-555-0903.", urgent: false },
  { id: 'v3', from: 'Unknown',             num: '+1 (305) 555-7184', via: 'Sales',          account: 'Premier Trucking', dur: '0:21', when: '4h ago',  read: true,  transcript: "Yeah hi, calling about your services. Trying to find pricing for a regular Miami to Atlanta run. Call me back.", urgent: false },
  { id: 'v4', from: 'Aniya Whitfield',      num: '+1 (206) 555-0117', via: 'Cascade Main',   account: 'Cascade Logistics', dur: '1:54', when: 'Yesterday', read: true,  transcript: "Hi team, Aniya here. I'm reviewing the Q4 numbers and I have a few questions about the dispatch margin reporting. Can someone walk me through the breakdown when you have a minute? I'm in office until 5.", urgent: false },
  { id: 'v5', from: 'Marcus Holloway',     num: '+1 (513) 904-6808', via: 'Driver Hotline', account: 'Premier Trucking', dur: '0:33', when: 'Mon',     read: true,  transcript: "Truck's running rough out by Lima. I'm pulling into the TA. Let me know how you want to handle this load.", urgent: false },
];

const SMS_THREADS = [
  { id: 's1', name: 'Marcus Holloway',  num: '+1 (513) 904-6808', preview: 'Got it, heading out now. ETA 4:30 to receiver.', when: '6m', unread: 2, kind: 'sms', via: 'Main Dispatch' },
  { id: 's2', name: 'Owen Bradshaw',    num: '+1 (614) 555-2241', preview: 'Photo of BOL attached', when: '32m', unread: 0, kind: 'sms', via: 'Driver Hotline' },
  { id: 's3', name: 'Devon Park',       num: '+1 (312) 555-0421', preview: "I'll send the rate confirmation in 10.", when: '1h', unread: 1, kind: 'sms', via: 'Main Dispatch' },
  { id: 's4', name: '+1 (305) 555-7184',num: '+1 (305) 555-7184', preview: 'STOP to opt out', when: '3h', unread: 0, kind: 'sms', via: 'Sales' },
  { id: 's5', name: 'Theodore Cole',    num: '+1 (614) 555-3022', preview: 'Will need a 30 min break in Toledo', when: 'Yest', unread: 0, kind: 'sms', via: 'Driver Hotline' },
];

const TEAM_CHANNELS = [
  { id: 't1', name: 'dispatch-floor',  preview: 'Priya: ok routing 4471 to Owen', when: '4m',  unread: 6, kind: 'channel', members: 12 },
  { id: 't2', name: 'after-hours-on-call', preview: 'Marcus: I can take tonight', when: '1h', unread: 0, kind: 'channel', members: 5 },
  { id: 't3', name: 'compliance',      preview: 'Yuki shared Q1 IFTA worksheet', when: '3h',  unread: 2, kind: 'channel', members: 4 },
  { id: 't4', name: 'leadership',      preview: 'Aniya: meeting moved to 2pm', when: 'Yest',  unread: 0, kind: 'channel', members: 6 },
];

const MESSAGES = [
  { id: 'm1', from: 'them', text: 'Heading to pickup now. Lot says check in at gate 4.', t: '2:14 PM' },
  { id: 'm2', from: 'me',   text: 'Sounds good. Receiver in Indianapolis is expecting you between 4 and 6.', t: '2:15 PM' },
  { id: 'm3', from: 'them', text: 'Copy. Loaded in 35, rolling.', t: '2:51 PM' },
  { id: 'm4', from: 'me',   text: 'Drive safe. Ping me if anything goes sideways.', t: '2:52 PM' },
  { id: 'm5', from: 'them', text: 'Got it, heading out now. ETA 4:30 to receiver.', t: '3:08 PM' },
];

const TRANSCRIPT = [
  { speaker: 'Easy Call (You)', name: 'You', t: '00:02', text: "Hey Devon, thanks for calling back. I've got Priya here with me too." },
  { speaker: 'Devon Park',      name: 'Devon Park', t: '00:08', text: "Hey, no problem. So I wanted to lock in that Cincinnati pickup for Friday — the 47k dry van you and I talked about Tuesday." },
  { speaker: 'Easy Call (You)', name: 'You', t: '00:21', text: "Right, the BlueRidge load. We can cover it. What's the rate looking like?" },
  { speaker: 'Devon Park',      name: 'Devon Park', t: '00:27', text: "I'm at $2,850 all-in to Indianapolis. I know it's a little tight but the receiver's flexible on the delivery window — anything from Friday afternoon to Saturday noon works." },
  { speaker: 'Easy Call (You)', name: 'You', t: '00:42', text: "Let me check on driver availability. Priya, who do we have rolling through Cincy on Friday?" },
  { speaker: 'Priya Raman',     name: 'Priya Raman', t: '00:51', text: "Marcus is empty out of Lexington Friday morning. He could grab it. Owen's another option but he's already got a Toledo run." },
  { speaker: 'Easy Call (You)', name: 'You', t: '01:04', text: "Devon, Marcus can take it. Send the rate con to dispatch@premiertrucking and we're good." },
];

const RING_GROUPS = [
  { id: 'rg1', name: 'Dispatch',       members: 4, strategy: 'Simultaneous', timeout: '20s' },
  { id: 'rg2', name: 'Sales Queue',    members: 3, strategy: 'Round-robin',  timeout: '30s' },
  { id: 'rg3', name: 'Driver Support', members: 6, strategy: 'Longest idle', timeout: '25s' },
  { id: 'rg4', name: 'Billing',        members: 2, strategy: 'Sequential',   timeout: '15s' },
];

const IVR_NODES = [
  { id: 'i1', key: '1', label: 'Driver Support',  routes: 'Driver Support queue' },
  { id: 'i2', key: '2', label: 'Existing Customer',routes: 'IVR submenu — Customer' },
  { id: 'i3', key: '3', label: 'New Business',     routes: 'Sales Queue' },
  { id: 'i4', key: '4', label: 'Billing',          routes: 'Billing ring group' },
  { id: 'i5', key: '0', label: 'Operator',         routes: 'User: Beatrice Yoon' },
];

const INTEGRATIONS = [
  { id: 'in1', name: 'Salesforce',      cat: 'CRM',         status: 'connected',    by: 'Priya Raman',    when: 'Mar 14' },
  { id: 'in2', name: 'HubSpot',         cat: 'CRM',         status: 'available',    by: '—',              when: '—'      },
  { id: 'in3', name: 'Google Calendar', cat: 'Calendar',    status: 'connected',    by: 'You',            when: 'Feb 02' },
  { id: 'in4', name: 'Microsoft 365',   cat: 'Calendar',    status: 'connected',    by: 'Aniya Whitfield',when: 'Jan 21' },
  { id: 'in5', name: 'Slack',           cat: 'Messaging',   status: 'connected',    by: 'You',            when: 'Mar 02' },
  { id: 'in6', name: 'Zendesk',         cat: 'Helpdesk',    status: 'available',    by: '—',              when: '—'      },
  { id: 'in7', name: 'Zapier',          cat: 'Automation',  status: 'connected',    by: 'You',            when: 'Apr 09' },
  { id: 'in8', name: 'Samsara',         cat: 'Telematics',  status: 'connected',    by: 'Priya Raman',    when: 'Mar 30' },
  { id: 'in9', name: 'QuickBooks',      cat: 'Accounting',  status: 'available',    by: '—',              when: '—'      },
  { id: 'in10',name: 'Webhooks',        cat: 'Automation',  status: 'configured',   by: 'You',            when: 'Apr 18' },
];

window.SAMPLE = { ACCOUNTS, NUMBERS, CONTACTS, CALLS, VOICEMAILS, SMS_THREADS, TEAM_CHANNELS, MESSAGES, TRANSCRIPT, RING_GROUPS, IVR_NODES, INTEGRATIONS };
