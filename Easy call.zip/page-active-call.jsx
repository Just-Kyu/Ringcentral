/* global React, Icon, UI, SAMPLE */
const { useState: useS2, useEffect: useE2 } = React;

// === Active call screen ===
const ActiveCall = ({ onEnd }) => {
  const [seconds, setSeconds] = useS2(247);
  const [muted, setMuted] = useS2(false);
  const [hold, setHold] = useS2(false);
  const [recording, setRecording] = useS2(true);
  const [keypad, setKeypad] = useS2(false);
  const [showTransfer, setShowTransfer] = useS2(false);
  const [tab, setTab] = useS2('transcript'); // transcript | notes | crm
  const [notes, setNotes] = useS2("• Confirmed Friday Cincinnati pickup, $2,850 all-in\n• Marcus assigned (empty out of Lexington AM)\n• Devon to send rate con to dispatch@\n• Receiver flexible Fri PM – Sat noon");

  useE2(() => {
    const t = setInterval(() => setSeconds(s => s + 1), 1000);
    return () => clearInterval(t);
  }, []);
  const fmt = (s) => `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;

  return (
    <div style={{display:'grid', gridTemplateColumns:'1fr 380px', height:'100%', minHeight:0}}>
      {/* Left: call stage */}
      <div style={{
        background: 'linear-gradient(180deg, #0E1B2C 0%, #15263B 100%)',
        color:'white',
        display:'flex', flexDirection:'column',
        position:'relative', overflow:'hidden'
      }}>
        {/* Top bar inside call */}
        <div style={{display:'flex', alignItems:'center', gap:10, padding:'14px 20px', borderBottom:'1px solid rgba(255,255,255,0.08)'}}>
          <span className="pill green" style={{background:'rgba(31,169,113,0.15)', color:'#5DD2A0', border:'none'}}>
            <span className="dot green"/> On-net · HD voice
          </span>
          {recording && <span className="pill" style={{background:'rgba(224,56,62,0.18)', color:'#FF7A7F', border:'none'}}><span className="rec-dot"/> Recording</span>}
          <span className="pill" style={{background:'rgba(255,255,255,0.08)', color:'rgba(255,255,255,0.85)', border:'none'}}>via Main Dispatch · Premier Trucking</span>
          <div className="spacer"/>
          <span className="mono" style={{fontSize:13, color:'rgba(255,255,255,0.85)'}}>{fmt(seconds)}</span>
        </div>

        {/* Participants */}
        <div style={{flex:1, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', padding:'20px', gap:24}}>
          <div style={{display:'flex', gap:36, alignItems:'flex-end'}}>
            <Participant name="Devon Park" sub="TrueRoute Brokerage" tone="tone-1" speaking/>
            <div style={{paddingBottom:18, color:'rgba(255,255,255,0.4)'}}>
              <Icon name="merge" size={20}/>
            </div>
            <Participant name="Priya Raman" sub="Dispatch Lead" tone="tone-3"/>
          </div>
          <div style={{textAlign:'center'}}>
            <div className="mono" style={{fontSize:13, color:'rgba(255,255,255,0.6)'}}>+1 (312) 555-0421</div>
            <div style={{fontSize:13, color:'rgba(255,255,255,0.5)', marginTop:4}}>2 participants · conference active</div>
          </div>
        </div>

        {/* Controls */}
        <div style={{padding:'18px 20px 26px', display:'flex', flexDirection:'column', gap:14, alignItems:'center', borderTop:'1px solid rgba(255,255,255,0.08)'}}>
          <div style={{display:'flex', gap:10, flexWrap:'wrap', justifyContent:'center'}}>
            <CallBtn icon={muted ? 'micOff' : 'mic'} label={muted ? 'Unmute' : 'Mute'} active={muted} onClick={() => setMuted(m => !m)}/>
            <CallBtn icon="pause" label={hold ? 'Resume' : 'Hold'} active={hold} onClick={() => setHold(h => !h)}/>
            <CallBtn icon="dialpad" label="Keypad" active={keypad} onClick={() => setKeypad(k => !k)}/>
            <CallBtn icon="record" label={recording ? 'Stop rec' : 'Record'} active={recording} accent="red" onClick={() => setRecording(r => !r)}/>
            <CallBtn icon="transfer" label="Transfer" active={showTransfer} onClick={() => setShowTransfer(s => !s)}/>
            <CallBtn icon="userPlus" label="Add"/>
            <CallBtn icon="merge" label="Merge"/>
            <CallBtn icon="volume" label="Audio"/>
            <CallBtn icon="more" label="More"/>
          </div>
          <button className="btn red" style={{padding:'12px 30px', borderRadius: 999, fontSize:14, fontWeight:600}} onClick={onEnd}>
            <Icon name="hangup" size={16}/> End call
          </button>
        </div>

        {keypad && (
          <KeypadOverlay onClose={() => setKeypad(false)}/>
        )}
        {showTransfer && (
          <TransferOverlay onClose={() => setShowTransfer(false)}/>
        )}
      </div>

      {/* Right: side panel */}
      <div style={{borderLeft:'1px solid var(--border)', background:'var(--surface)', display:'flex', flexDirection:'column', minHeight:0}}>
        <div className="list-tabs" style={{padding:'0 12px'}}>
          <button className={"list-tab " + (tab==='transcript'?'active':'')} onClick={() => setTab('transcript')}>
            <Icon name="sparkle" size={12} style={{marginRight:4, verticalAlign:'-2px'}}/>Transcript
          </button>
          <button className={"list-tab " + (tab==='notes'?'active':'')} onClick={() => setTab('notes')}>Notes</button>
          <button className={"list-tab " + (tab==='crm'?'active':'')} onClick={() => setTab('crm')}>Contact</button>
        </div>
        <div style={{flex:1, overflow:'auto', padding:16}}>
          {tab === 'transcript' && <Transcript/>}
          {tab === 'notes' && (
            <textarea className="textarea" value={notes} onChange={e => setNotes(e.target.value)} style={{minHeight:'100%', height:'100%', resize:'none', fontFamily:'var(--font-ui)', lineHeight:1.55}}/>
          )}
          {tab === 'crm' && <CrmPanel/>}
        </div>
      </div>
    </div>
  );
};

const Participant = ({ name, sub, tone, speaking }) => (
  <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:10}}>
    <div className={"av xl " + tone} style={{
      width: 132, height: 132, fontSize: 38,
      animation: speaking ? 'pulse-ring 1.6s infinite' : 'none',
    }}>{UI.initials(name)}</div>
    <div style={{textAlign:'center'}}>
      <div style={{fontWeight:600, fontSize:17}}>{name}</div>
      <div style={{color:'rgba(255,255,255,0.55)', fontSize:13}}>{sub}</div>
    </div>
  </div>
);

const CallBtn = ({ icon, label, active, accent, onClick }) => {
  const bg = active
    ? (accent === 'red' ? 'rgba(224,56,62,0.85)' : 'rgba(255,255,255,0.95)')
    : 'rgba(255,255,255,0.08)';
  const fg = active ? (accent === 'red' ? 'white' : '#0E1B2C') : 'rgba(255,255,255,0.95)';
  return (
    <button onClick={onClick} style={{
      display:'flex', flexDirection:'column', alignItems:'center', gap:5,
      padding:'10px 12px', minWidth: 70,
      background: bg, color: fg, border:'none', borderRadius: 12, cursor:'pointer',
      transition:'background 0.15s',
    }}>
      <Icon name={icon} size={18}/>
      <span style={{fontSize:11, fontWeight:500}}>{label}</span>
    </button>
  );
};

const KeypadOverlay = ({ onClose }) => (
  <div style={{position:'absolute', bottom: 130, left:'50%', transform:'translateX(-50%)', background:'var(--surface)', color:'var(--text)', borderRadius:14, padding:14, boxShadow:'var(--shadow-lg)', width: 240}}>
    <div style={{display:'flex', alignItems:'center', marginBottom:8}}>
      <div style={{fontSize:12, fontWeight:600}}>Keypad</div>
      <div className="spacer"/>
      <button className="btn ghost icon sm" onClick={onClose}><Icon name="close" size={12}/></button>
    </div>
    <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:6}}>
      {['1','2','3','4','5','6','7','8','9','*','0','#'].map(k => (
        <button key={k} style={{padding:'10px 0', background:'var(--surface-2)', border:'1px solid var(--border)', borderRadius:8, fontSize:16, fontFamily:'var(--font-mono)'}}>{k}</button>
      ))}
    </div>
  </div>
);

const TransferOverlay = ({ onClose }) => (
  <div style={{position:'absolute', bottom: 130, left:'50%', transform:'translateX(-50%)', background:'var(--surface)', color:'var(--text)', borderRadius:14, padding:16, boxShadow:'var(--shadow-lg)', width: 360}}>
    <div style={{display:'flex', alignItems:'center', marginBottom:10}}>
      <div style={{fontSize:13, fontWeight:600}}>Transfer call</div>
      <div className="spacer"/>
      <button className="btn ghost icon sm" onClick={onClose}><Icon name="close" size={12}/></button>
    </div>
    <div style={{display:'flex', gap:6, marginBottom:10}}>
      <button className="btn sm primary" style={{flex:1}}>Warm</button>
      <button className="btn sm" style={{flex:1}}>Blind</button>
    </div>
    <input className="input" placeholder="Search teammate, queue, or number…" style={{marginBottom:8}}/>
    {[
      {n:'Priya Raman', s:'Dispatch Lead · 4101'},
      {n:'Driver Support queue', s:'6 agents available'},
      {n:'Beatrice Yoon', s:'Receptionist · 4100'},
    ].map((r, i) => (
      <div key={i} style={{display:'flex', alignItems:'center', gap:10, padding:'8px 6px', borderRadius:8}} className="hover-row">
        <div className={"av sm " + UI.toneFor(r.n)}>{UI.initials(r.n)}</div>
        <div style={{flex:1, minWidth:0}}>
          <div style={{fontSize:13, fontWeight:500}}>{r.n}</div>
          <div className="soft" style={{fontSize:11}}>{r.s}</div>
        </div>
        <button className="btn primary sm">Transfer</button>
      </div>
    ))}
  </div>
);

const Transcript = () => (
  <div className="col" style={{gap:14}}>
    <div className="pill orange" style={{alignSelf:'flex-start'}}><Icon name="sparkle" size={11}/> Live AI transcription</div>
    {SAMPLE.TRANSCRIPT.map((line, i) => (
      <div key={i} style={{display:'flex', gap:10}}>
        <div className={"av sm " + UI.toneFor(line.name)} style={{flexShrink:0}}>{UI.initials(line.name)}</div>
        <div style={{flex:1, minWidth:0}}>
          <div style={{display:'flex', alignItems:'baseline', gap:8, marginBottom:2}}>
            <div style={{fontSize:12.5, fontWeight:600}}>{line.name}</div>
            <div className="soft mono" style={{fontSize:10.5}}>{line.t}</div>
          </div>
          <div style={{fontSize:13, lineHeight:1.5, color:'var(--text-muted)'}}>{line.text}</div>
        </div>
      </div>
    ))}
    <div style={{padding:'10px 12px', background:'var(--surface-2)', border:'1px dashed var(--border-strong)', borderRadius:10, color:'var(--text-soft)', fontSize:12, fontStyle:'italic', display:'flex', alignItems:'center', gap:8}}>
      <span className="rec-dot"/> Listening…
    </div>
  </div>
);

const CrmPanel = () => (
  <div className="col" style={{gap:14}}>
    <div style={{display:'flex', gap:12, alignItems:'center'}}>
      <div className={"av lg tone-4"}>{UI.initials('Devon Park')}</div>
      <div style={{flex:1, minWidth:0}}>
        <div style={{fontSize:15, fontWeight:600}}>Devon Park</div>
        <div className="soft" style={{fontSize:12}}>Broker · TrueRoute Brokerage</div>
        <div style={{display:'flex', gap:6, marginTop:6}}>
          <span className="pill orange">VIP</span>
          <span className="pill slate">Broker</span>
        </div>
      </div>
    </div>
    <div className="hr"/>
    <KV k="Phone" v="+1 (312) 555-0421" mono/>
    <KV k="Email" v="devon@trueroute.io"/>
    <KV k="Account owner" v="Priya Raman"/>
    <KV k="Last contact" v="Tue · 14:22 outbound call"/>
    <div className="hr"/>
    <div>
      <div className="label" style={{marginBottom:8}}>Open in CRM</div>
      <div style={{display:'flex', gap:6, flexWrap:'wrap'}}>
        <button className="btn sm"><Icon name="external" size={12}/> Salesforce</button>
        <button className="btn sm"><Icon name="external" size={12}/> HubSpot deal</button>
      </div>
    </div>
    <div className="hr"/>
    <div>
      <div className="label" style={{marginBottom:8}}>Recent activity</div>
      {[
        {i:'phoneOut', t:'Outbound · 12:03', d:'Tue 2:14 PM'},
        {i:'phoneIn',  t:'Inbound · 4:22',   d:'Mar 28'},
        {i:'message',  t:'SMS thread',        d:'Mar 21'},
      ].map((a,i) => (
        <div key={i} style={{display:'flex', gap:8, alignItems:'center', padding:'6px 0'}}>
          <Icon name={a.i} size={14}/>
          <div style={{flex:1, fontSize:12.5}}>{a.t}</div>
          <div className="soft" style={{fontSize:11}}>{a.d}</div>
        </div>
      ))}
    </div>
  </div>
);

const KV = ({ k, v, mono }) => (
  <div style={{display:'flex', alignItems:'center'}}>
    <div className="soft" style={{fontSize:12, width:110}}>{k}</div>
    <div className={mono ? 'mono' : ''} style={{fontSize:13, fontWeight:500}}>{v}</div>
  </div>
);

window.PageActiveCall = ActiveCall;
