/* global React, Icon, UI, SAMPLE */
const { useState: useS5 } = React;

// === Numbers page ===
const NumbersPage = () => {
  const [sel, setSel] = useS5(SAMPLE.NUMBERS[0].id);
  const n = SAMPLE.NUMBERS.find(x => x.id === sel);
  return (
    <div className="page">
      <div className="page-head">
        <div style={{flex:1}}>
          <h2 className="page-title">Numbers</h2>
          <div className="page-sub">{SAMPLE.NUMBERS.length} numbers across {SAMPLE.ACCOUNTS.length} accounts · {SAMPLE.NUMBERS.filter(x => x.sms).length} SMS-enabled</div>
        </div>
        <button className="btn"><Icon name="upload" size={14}/> Port a number</button>
        <button className="btn primary"><Icon name="add" size={14}/> Buy number</button>
      </div>
      <div className="card">
        <div style={{display:'flex', alignItems:'center', gap:8, padding:'12px 16px', borderBottom:'1px solid var(--border)'}}>
          <div className="search-wrap" style={{flex:1, maxWidth:360}}>
            <Icon name="search" size={14}/>
            <input className="search" placeholder="Search numbers, labels, area codes" style={{width:'100%'}}/>
          </div>
          <button className="btn sm"><Icon name="filter" size={12}/> All accounts</button>
          <button className="btn sm"><Icon name="filter" size={12}/> All types</button>
          <button className="btn sm"><Icon name="filter" size={12}/> Status</button>
          <div className="spacer"/>
          <button className="btn ghost icon"><Icon name="download" size={14}/></button>
        </div>
        <table>
          <thead>
            <tr>
              <th style={{width:36}}><input type="checkbox"/></th>
              <th>Number</th>
              <th>Label</th>
              <th>Account</th>
              <th>Type</th>
              <th>Routes to</th>
              <th>SMS</th>
              <th>Status</th>
              <th style={{width:60}}></th>
            </tr>
          </thead>
          <tbody>
            {SAMPLE.NUMBERS.map(num => (
              <tr key={num.id} className={num.id === sel ? 'selected' : ''} onClick={() => setSel(num.id)}>
                <td><input type="checkbox" onClick={e => e.stopPropagation()}/></td>
                <td className="mono" style={{fontWeight:500}}>{num.number}</td>
                <td>{num.label}</td>
                <td className="muted">{num.account}</td>
                <td><span className="pill slate">{num.type}</span></td>
                <td className="muted" style={{fontSize:12.5}}>{num.fwd}</td>
                <td>{num.sms ? <Icon name="check" size={14} style={{color:'var(--green)'}}/> : <span className="soft">—</span>}</td>
                <td><UI.StatusChip status={num.status}/></td>
                <td><button className="btn ghost icon" onClick={e => e.stopPropagation()}><Icon name="more" size={14}/></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {n && (
        <div className="card" style={{marginTop:16}}>
          <div className="card-head">
            <div>
              <div className="card-title">{n.label} · <span className="mono">{n.number}</span></div>
              <div className="card-sub">{n.account} · {n.type}</div>
            </div>
            <div className="spacer"/>
            <button className="btn"><Icon name="edit" size={13}/> Edit routing</button>
            <button className="btn"><Icon name="settings" size={13}/> Settings</button>
          </div>
          <div className="card-body" style={{display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:16}}>
            <Stat k="Calls (7 days)" v="142"/>
            <Stat k="Avg. duration" v="3:41"/>
            <Stat k="Missed rate" v="6.3%" trend="down"/>
            <Stat k="Monthly cost" v="$3.50"/>
          </div>
        </div>
      )}
    </div>
  );
};

const Stat = ({ k, v, trend }) => (
  <div>
    <div className="soft" style={{fontSize:11, textTransform:'uppercase', letterSpacing:'0.06em', fontWeight:600}}>{k}</div>
    <div style={{fontSize:22, fontWeight:600, marginTop:4, fontFamily:'var(--font-mono)'}}>{v}</div>
    {trend && <div className="pill green" style={{marginTop:4}}><Icon name="arrowDown" size={10}/> Down 2.1%</div>}
  </div>
);

// === Routing / IVR / Queues ===
const RoutingPage = () => {
  return (
    <div className="page">
      <div className="page-head">
        <div style={{flex:1}}>
          <h2 className="page-title">Call routing</h2>
          <div className="page-sub">IVR menus, ring groups, queues, and business hours</div>
        </div>
        <button className="btn"><Icon name="copy" size={13}/> Templates</button>
        <button className="btn primary"><Icon name="add" size={14}/> New flow</button>
      </div>

      <div className="grid" style={{gridTemplateColumns:'1.4fr 1fr', gap:16}}>
        <div className="card">
          <div className="card-head">
            <Icon name="routing" size={14}/>
            <div className="card-title">Main IVR · Premier Trucking</div>
            <span className="pill green" style={{marginLeft:8}}><span className="dot green"/> Live</span>
            <div className="spacer"/>
            <button className="btn sm ghost"><Icon name="edit" size={12}/> Edit</button>
          </div>
          <div className="card-body">
            <div style={{padding:14, background:'var(--surface-2)', border:'1px solid var(--border)', borderRadius:10, marginBottom:14}}>
              <div className="label" style={{marginBottom:6}}>Greeting (audio)</div>
              <div style={{display:'flex', alignItems:'center', gap:10}}>
                <button className="btn primary icon" style={{width:32, height:32, borderRadius:'50%'}}><Icon name="play" size={12}/></button>
                <div style={{flex:1}}>
                  <div style={{fontSize:13}}>Premier_main_v3.mp3</div>
                  <div className="soft" style={{fontSize:11}}>"Thank you for calling Premier Trucking Group. For drivers on the road, press 1…"</div>
                </div>
                <span className="soft mono" style={{fontSize:11}}>0:18</span>
              </div>
            </div>
            <div className="label" style={{marginBottom:8}}>Menu options</div>
            <div className="col" style={{gap:8}}>
              {SAMPLE.IVR_NODES.map(node => (
                <div key={node.id} style={{display:'flex', alignItems:'center', gap:12, padding:'10px 12px', background:'var(--surface)', border:'1px solid var(--border)', borderRadius:10}}>
                  <div className="mono" style={{width:32, height:32, borderRadius:8, background:'var(--ec-orange-50)', color:'var(--ec-orange-600)', display:'grid', placeItems:'center', fontWeight:600}}>{node.key}</div>
                  <div style={{flex:1}}>
                    <div style={{fontSize:13, fontWeight:500}}>{node.label}</div>
                    <div className="soft" style={{fontSize:11.5, display:'flex', alignItems:'center', gap:4}}><Icon name="arrowRight" size={11}/> {node.routes}</div>
                  </div>
                  <button className="btn ghost icon"><Icon name="more" size={14}/></button>
                </div>
              ))}
              <button className="btn ghost" style={{justifyContent:'flex-start', borderStyle:'dashed', borderColor:'var(--border-strong)', borderWidth:1}}><Icon name="add" size={13}/> Add option</button>
            </div>
          </div>
        </div>

        <div className="col" style={{gap:16}}>
          <div className="card">
            <div className="card-head">
              <Icon name="team" size={14}/>
              <div className="card-title">Ring groups & queues</div>
              <div className="spacer"/>
              <button className="btn sm ghost"><Icon name="add" size={12}/> New</button>
            </div>
            <div>
              {SAMPLE.RING_GROUPS.map(g => (
                <div key={g.id} style={{display:'flex', alignItems:'center', gap:12, padding:'12px 16px', borderBottom:'1px solid var(--border)'}}>
                  <Icon name="team" size={16} style={{color:'var(--text-soft)'}}/>
                  <div style={{flex:1}}>
                    <div style={{fontSize:13.5, fontWeight:500}}>{g.name}</div>
                    <div className="soft" style={{fontSize:11.5}}>{g.members} agents · {g.strategy} · timeout {g.timeout}</div>
                  </div>
                  <button className="btn ghost icon"><Icon name="more" size={14}/></button>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <div className="card-head">
              <Icon name="calendar" size={14}/>
              <div className="card-title">Business hours</div>
              <div className="spacer"/>
              <span className="pill green"><span className="dot green"/> Open now</span>
            </div>
            <div className="card-body col" style={{gap:8}}>
              {[['Mon–Fri','7:00 AM – 7:00 PM'],['Saturday','8:00 AM – 2:00 PM'],['Sunday','Closed (after-hours routing)']].map(([d, h]) => (
                <div key={d} style={{display:'flex'}}>
                  <div className="muted" style={{width:120, fontSize:13}}>{d}</div>
                  <div className="mono" style={{fontSize:13}}>{h}</div>
                </div>
              ))}
              <div className="hr"/>
              <div className="row"><Icon name="globe" size={13}/><span style={{fontSize:12.5}}>Time zone: America/New_York</span></div>
            </div>
          </div>

          <div className="card">
            <div className="card-head">
              <Icon name="bolt" size={14}/>
              <div className="card-title">After-hours fallback</div>
            </div>
            <div className="card-body col" style={{gap:10}}>
              <div className="row"><Icon name="voicemail" size={14}/><span style={{fontSize:13}}>Send to <strong>shared voicemail</strong></span></div>
              <div className="row"><Icon name="message" size={14}/><span style={{fontSize:13}}>Auto-reply: "We're closed — drivers, text 'HELP' for emergency dispatch."</span></div>
              <div className="row"><Icon name="phone" size={14}/><span style={{fontSize:13}}>Forward urgent (DTMF 9) to <strong>on-call rotation</strong></span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

window.PageNumbers = NumbersPage;
window.PageRouting = RoutingPage;
