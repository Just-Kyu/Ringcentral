/* global React, Icon, UI, SAMPLE */
const { useState: useS3 } = React;

const dirIcon = (c) => c.status === 'missed' ? 'phoneMissed' : c.dir === 'in' ? 'phoneIn' : 'phoneOut';
const dirColor = (c) => c.status === 'missed' ? 'var(--red)' : c.dir === 'in' ? 'var(--green)' : 'var(--text-muted)';

// === Call History ===
const HistoryPage = ({ onOpenActive }) => {
  const [tab, setTab] = useS3('all');
  const [sel, setSel] = useS3(SAMPLE.CALLS[0].id);
  const tabs = [
    { id: 'all', label: 'All', count: SAMPLE.CALLS.length },
    { id: 'missed', label: 'Missed', count: SAMPLE.CALLS.filter(c => c.status === 'missed').length },
    { id: 'recorded', label: 'Recorded', count: SAMPLE.CALLS.filter(c => c.recorded).length },
    { id: 'inbound', label: 'Inbound', count: SAMPLE.CALLS.filter(c => c.dir === 'in').length },
    { id: 'outbound', label: 'Outbound', count: SAMPLE.CALLS.filter(c => c.dir === 'out').length },
  ];
  const filtered = SAMPLE.CALLS.filter(c => {
    if (tab === 'all') return true;
    if (tab === 'missed') return c.status === 'missed';
    if (tab === 'recorded') return c.recorded;
    if (tab === 'inbound') return c.dir === 'in';
    if (tab === 'outbound') return c.dir === 'out';
  });
  const selCall = filtered.find(c => c.id === sel) || filtered[0];

  return (
    <div className="content">
      <div className="list-pane" style={{width: 380}}>
        <div className="list-head">
          <div style={{display:'flex', alignItems:'center', gap:8, marginBottom:8}}>
            <div style={{fontWeight:600, fontSize:14}}>Call history</div>
            <div className="spacer"/>
            <button className="btn ghost icon"><Icon name="filter" size={14}/></button>
            <button className="btn ghost icon"><Icon name="download" size={14}/></button>
          </div>
          <div className="search-wrap">
            <Icon name="search" size={14}/>
            <input className="search" placeholder="Search calls" style={{width:'100%'}}/>
          </div>
        </div>
        <div className="list-tabs" style={{paddingLeft: 8}}>
          {tabs.map(t => (
            <button key={t.id} className={"list-tab " + (tab===t.id?'active':'')} onClick={() => setTab(t.id)}>
              {t.label} <span className="soft mono" style={{fontSize:10, marginLeft:3}}>{t.count}</span>
            </button>
          ))}
        </div>
        <div className="list-items">
          {filtered.map(c => (
            <div key={c.id} className={"list-item" + (c.id===sel ? ' selected' : '')} onClick={() => setSel(c.id)}>
              <div className={"av " + UI.toneFor(c.to)}>{UI.initials(c.to === 'Unknown' ? '?' : c.to)}</div>
              <div style={{flex:1, minWidth:0}}>
                <div style={{display:'flex', alignItems:'baseline', gap:6}}>
                  <div style={{fontWeight:600, fontSize:13.5, color: c.status==='missed' ? 'var(--red)' : 'inherit'}}>{c.to}</div>
                  <div className="spacer"/>
                  <div className="soft" style={{fontSize:11}}>{c.when}</div>
                </div>
                <div style={{display:'flex', alignItems:'center', gap:6, marginTop:2}}>
                  <Icon name={dirIcon(c)} size={11} style={{color: dirColor(c)}}/>
                  <span className="mono soft" style={{fontSize:11.5}}>{c.num}</span>
                </div>
                <div style={{display:'flex', alignItems:'center', gap:8, marginTop:5}}>
                  <span className="soft" style={{fontSize:11}}>via {c.via} · {c.dur}</span>
                  {c.recorded && <span className="pill" style={{fontSize:10, padding:'1px 6px'}}><Icon name="record" size={9}/> rec</span>}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="detail-pane">
        {selCall && <CallDetail call={selCall} onCallBack={onOpenActive}/>}
      </div>
    </div>
  );
};

const CallDetail = ({ call, onCallBack }) => (
  <div className="page" style={{maxWidth: 880}}>
    <div className="page-head" style={{alignItems:'center'}}>
      <div className={"av xl " + UI.toneFor(call.to)} style={{width:64, height:64, fontSize:22}}>{UI.initials(call.to === 'Unknown' ? '?' : call.to)}</div>
      <div style={{flex:1, minWidth:0}}>
        <h2 className="page-title">{call.to}</h2>
        <div className="page-sub mono">{call.num}</div>
        <div style={{display:'flex', gap:6, marginTop:8, flexWrap:'wrap'}}>
          <span className="pill"><Icon name={dirIcon(call)} size={11} style={{color: dirColor(call)}}/> {call.dir === 'in' ? 'Inbound' : 'Outbound'}</span>
          <span className="pill slate">via {call.via}</span>
          <span className="pill slate">{call.account}</span>
          <UI.StatusChip status={call.status}/>
          {call.recorded && <span className="pill orange"><Icon name="record" size={11}/> Recorded</span>}
        </div>
      </div>
      <button className="btn primary" onClick={onCallBack}><Icon name="phone" size={14}/> Call back</button>
      <button className="btn"><Icon name="message" size={14}/> Text</button>
      <button className="btn ghost icon"><Icon name="more" size={16}/></button>
    </div>

    <div className="grid" style={{gridTemplateColumns:'2fr 1fr'}}>
      <div className="col" style={{gap:16}}>
        {call.recorded && (
          <div className="card">
            <div className="card-head">
              <Icon name="play" size={14}/>
              <div className="card-title">Recording</div>
              <div className="spacer"/>
              <span className="soft mono" style={{fontSize:12}}>{call.dur}</span>
              <button className="btn ghost icon"><Icon name="download" size={14}/></button>
            </div>
            <div className="card-body">
              <div style={{display:'flex', alignItems:'center', gap:12}}>
                <button className="btn primary icon" style={{width:40, height:40, borderRadius:'50%'}}><Icon name="play" size={16}/></button>
                <div style={{flex:1}}>
                  <Waveform/>
                  <div style={{display:'flex', justifyContent:'space-between', marginTop:6}} className="soft mono">
                    <span style={{fontSize:11}}>00:00</span>
                    <span style={{fontSize:11}}>{call.dur}</span>
                  </div>
                </div>
                <button className="btn ghost icon"><Icon name="volume" size={14}/></button>
              </div>
            </div>
          </div>
        )}

        <div className="card">
          <div className="card-head">
            <Icon name="sparkle" size={14}/>
            <div className="card-title">AI summary</div>
            <span className="pill orange" style={{marginLeft:8}}>Auto-generated</span>
          </div>
          <div className="card-body">
            <p style={{margin:'0 0 12px', color:'var(--text-muted)', lineHeight:1.6}}>
              Devon Park (TrueRoute Brokerage) confirmed a 47,000 lb dry-van load departing Cincinnati on Friday at 8 AM, heading to Indianapolis. Rate locked at <strong>$2,850 all-in</strong>. Receiver is flexible from Friday afternoon through Saturday noon. Marcus Holloway will run the load — he's empty out of Lexington Friday morning. Devon will email the rate confirmation to dispatch within 10 minutes.
            </p>
            <div className="label" style={{marginBottom:6}}>Action items</div>
            <ul style={{margin:0, paddingLeft:18, lineHeight:1.7, fontSize:13}}>
              <li>Wait for rate confirmation from <strong>devon@trueroute.io</strong></li>
              <li>Assign load <strong>BR-Cincy-04/26</strong> to Marcus Holloway in dispatch board</li>
              <li>Notify Marcus of pickup time and BlueRidge Produce contact</li>
            </ul>
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <Icon name="notes" size={14}/>
            <div className="card-title">Transcript</div>
            <div className="spacer"/>
            <button className="btn sm ghost"><Icon name="copy" size={12}/> Copy</button>
          </div>
          <div className="card-body">
            {SAMPLE.TRANSCRIPT.slice(0, 5).map((l, i) => (
              <div key={i} style={{display:'flex', gap:10, marginBottom:10}}>
                <div className="soft mono" style={{fontSize:11, width:42, paddingTop:2}}>{l.t}</div>
                <div style={{flex:1}}>
                  <div style={{fontWeight:600, fontSize:12.5, marginBottom:2}}>{l.name}</div>
                  <div style={{fontSize:13, color:'var(--text-muted)', lineHeight:1.5}}>{l.text}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="col" style={{gap:16}}>
        <div className="card">
          <div className="card-head">
            <div className="card-title">Call details</div>
          </div>
          <div className="card-body col" style={{gap:10}}>
            <KVRow k="Direction" v={call.dir === 'in' ? 'Inbound' : 'Outbound'}/>
            <KVRow k="Duration" v={call.dur} mono/>
            <KVRow k="Connected via" v={call.via}/>
            <KVRow k="Account" v={call.account}/>
            <KVRow k="Started" v={call.when}/>
            <KVRow k="From" v={call.dir === 'in' ? call.num : '+1 (513) 776-4064'} mono/>
            <KVRow k="To" v={call.dir === 'in' ? '+1 (513) 776-4064' : call.num} mono/>
            <KVRow k="Cost" v="$0.018"/>
          </div>
        </div>

        <div className="card">
          <div className="card-head"><div className="card-title">Tags & notes</div></div>
          <div className="card-body col" style={{gap:10}}>
            <div style={{display:'flex', gap:6, flexWrap:'wrap'}}>
              <span className="pill orange">Load · BR-04/26</span>
              <span className="pill slate">Broker call</span>
              <button className="btn sm ghost"><Icon name="add" size={11}/> Tag</button>
            </div>
            <textarea className="textarea" rows="3" placeholder="Add notes…" defaultValue="Rate locked. Send to Marcus."/>
          </div>
        </div>
      </div>
    </div>
  </div>
);

const KVRow = ({ k, v, mono }) => (
  <div style={{display:'flex'}}>
    <div className="soft" style={{fontSize:12, width:120}}>{k}</div>
    <div className={mono ? 'mono' : ''} style={{fontSize:13, fontWeight:500}}>{v}</div>
  </div>
);

const Waveform = () => {
  // pseudo-random bars
  const bars = Array.from({length: 60}, (_, i) => 6 + Math.abs(Math.sin(i * 0.7) * 18) + (i % 5) * 2);
  return (
    <div style={{display:'flex', gap:2, alignItems:'center', height:32}}>
      {bars.map((h, i) => (
        <div key={i} style={{flex:1, height: h, background: i < 24 ? 'var(--ec-orange)' : 'var(--border-strong)', borderRadius: 2}}/>
      ))}
    </div>
  );
};

// === Voicemail ===
const VoicemailPage = () => {
  const [sel, setSel] = useS3(SAMPLE.VOICEMAILS[0].id);
  const v = SAMPLE.VOICEMAILS.find(x => x.id === sel);
  return (
    <div className="content">
      <div className="list-pane">
        <div className="list-head">
          <div style={{display:'flex', alignItems:'center'}}>
            <div style={{fontWeight:600, fontSize:14}}>Voicemail</div>
            <span className="pill orange" style={{marginLeft:8}}>{SAMPLE.VOICEMAILS.filter(x => !x.read).length} new</span>
            <div className="spacer"/>
            <button className="btn ghost icon"><Icon name="filter" size={14}/></button>
          </div>
        </div>
        <div className="list-items">
          {SAMPLE.VOICEMAILS.map(vm => (
            <div key={vm.id} className={"list-item" + (vm.id===sel?' selected':'')} onClick={() => setSel(vm.id)}>
              <div style={{position:'relative'}}>
                <div className={"av " + UI.toneFor(vm.from)}>{UI.initials(vm.from === 'Unknown' ? '?' : vm.from)}</div>
                {!vm.read && <div style={{position:'absolute', top:-2, right:-2, width:10, height:10, borderRadius:'50%', background:'var(--ec-orange)', border:'2px solid var(--surface)'}}/>}
              </div>
              <div style={{flex:1, minWidth:0}}>
                <div style={{display:'flex', alignItems:'baseline', gap:6}}>
                  <div style={{fontWeight: vm.read ? 500 : 700, fontSize:13.5}}>{vm.from}</div>
                  {vm.urgent && <span className="pill red" style={{fontSize:10, padding:'1px 6px'}}>Urgent</span>}
                  <div className="spacer"/>
                  <div className="soft mono" style={{fontSize:11}}>{vm.dur}</div>
                </div>
                <div className="soft mono" style={{fontSize:11.5, marginTop:2}}>{vm.num} · via {vm.via}</div>
                <div className="soft" style={{fontSize:12, marginTop:4, lineHeight:1.4, overflow:'hidden', display:'-webkit-box', WebkitLineClamp:2, WebkitBoxOrient:'vertical'}}>{vm.transcript}</div>
                <div className="soft" style={{fontSize:11, marginTop:4}}>{vm.when}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="detail-pane">
        {v && (
          <div className="page" style={{maxWidth:780}}>
            <div className="page-head" style={{alignItems:'center'}}>
              <div className={"av xl " + UI.toneFor(v.from)} style={{width:64, height:64, fontSize:22}}>{UI.initials(v.from === 'Unknown' ? '?' : v.from)}</div>
              <div style={{flex:1}}>
                <h2 className="page-title">{v.from}</h2>
                <div className="page-sub mono">{v.num}</div>
                <div style={{display:'flex', gap:6, marginTop:8}}>
                  <span className="pill slate">via {v.via}</span>
                  <span className="pill slate">{v.account}</span>
                  <span className="pill">{v.when} · {v.dur}</span>
                  {v.urgent && <span className="pill red">Urgent</span>}
                </div>
              </div>
              <button className="btn primary"><Icon name="phone" size={14}/> Call back</button>
              <button className="btn"><Icon name="message" size={14}/> Text</button>
              <button className="btn ghost icon"><Icon name="more" size={16}/></button>
            </div>

            <div className="card" style={{marginBottom:16}}>
              <div className="card-body">
                <div style={{display:'flex', alignItems:'center', gap:12}}>
                  <button className="btn primary icon" style={{width:44, height:44, borderRadius:'50%'}}><Icon name="play" size={18}/></button>
                  <div style={{flex:1}}>
                    <Waveform/>
                    <div style={{display:'flex', justifyContent:'space-between', marginTop:6}} className="soft mono">
                      <span style={{fontSize:11}}>00:00</span>
                      <span style={{fontSize:11}}>{v.dur}</span>
                    </div>
                  </div>
                  <button className="btn"><Icon name="download" size={14}/> MP3</button>
                </div>
              </div>
            </div>

            <div className="card">
              <div className="card-head">
                <Icon name="sparkle" size={14}/>
                <div className="card-title">Transcript</div>
                <span className="pill orange" style={{marginLeft:8}}>AI</span>
                <div className="spacer"/>
                <button className="btn sm ghost"><Icon name="copy" size={12}/> Copy</button>
                <button className="btn sm ghost"><Icon name="flag" size={12}/> Flag inaccuracy</button>
              </div>
              <div className="card-body">
                <p style={{margin:0, fontSize:14.5, lineHeight:1.7, color:'var(--text)'}}>{v.transcript}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

window.PageHistory = HistoryPage;
window.PageVoicemail = VoicemailPage;
