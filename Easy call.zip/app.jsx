/* global React, ReactDOM, Icon, UI, SAMPLE,
   PagePhone, PageActiveCall, PageHistory, PageVoicemail, PageMessages, PageContacts,
   PageNumbers, PageSettings,
   IncomingCall, SignIn,
   useTweaks, TweaksPanel, TweakSection, TweakRadio, TweakToggle, TweakSelect */
const { useState, useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "light",
  "density": "comfortable",
  "rail": "expanded",
  "showIncoming": false
}/*EDITMODE-END*/;

const PAGE_TITLES = {
  phone:        ['Phone',          'Place a call from any of your business numbers'],
  history:      ['Call history',   'Recordings, transcripts, and AI summaries'],
  voicemail:    ['Voicemail',      'Visual voicemail with transcription'],
  messages:     ['Messages',       'SMS to customers and team chat in one inbox'],
  contacts:     ['Contacts',       'People, drivers, brokers, and vendors'],
  numbers:      ['Numbers',        'Manage every number across every account'],
  settings:     ['Settings',       'Personal preferences and devices'],
};

const App = () => {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [signedIn, setSignedIn] = useState(true);
  const [page, setPage] = useState('phone');
  const [activeCallOpen, setActiveCallOpen] = useState(false);
  const [accountFilter, setAccountFilter] = useState('all');
  const [showIncoming, setShowIncoming] = useState(false);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', tweaks.theme);
    document.documentElement.setAttribute('data-density', tweaks.density);
  }, [tweaks.theme, tweaks.density]);

  if (!signedIn) {
    return <SignIn onSignIn={() => setSignedIn(true)} onBack={() => setSignedIn(true)}/>;
  }

  const [title, sub] = PAGE_TITLES[page] || ['', ''];

  let content;
  if (activeCallOpen) {
    content = <PageActiveCall onEnd={() => setActiveCallOpen(false)}/>;
  } else {
    switch (page) {
      case 'phone':        content = <PagePhone/>; break;
      case 'history':      content = <PageHistory onOpenActive={() => setActiveCallOpen(true)}/>; break;
      case 'voicemail':    content = <PageVoicemail/>; break;
      case 'messages':     content = <PageMessages/>; break;
      case 'contacts':     content = <PageContacts/>; break;
      case 'numbers':      content = <PageNumbers/>; break;
      case 'settings':     content = <PageSettings/>; break;
      default:             content = <PagePhone/>;
    }
  }

  return (
    <div className="app" data-rail={tweaks.rail} data-screen-label="01 Easy Call dashboard">
      <UI.Rail
        active={activeCallOpen ? 'phone' : page}
        onNav={(id) => { setActiveCallOpen(false); setPage(id); }}
        collapsed={tweaks.rail === 'collapsed'}
        onToggle={() => setTweak('rail', tweaks.rail === 'collapsed' ? 'expanded' : 'collapsed')}
        accounts={SAMPLE.ACCOUNTS}
      />
      <div className="main">
        {!activeCallOpen && (
          <UI.Topbar
            title={title}
            subtitle={sub}
            accounts={SAMPLE.ACCOUNTS}
            accountFilter={accountFilter}
            onAccountFilter={setAccountFilter}
            right={
              <>
                <button className="btn ghost icon" title="Simulate incoming" onClick={() => setShowIncoming(true)}>
                  <Icon name="phoneIn" size={16}/>
                </button>
                <button className="btn" onClick={() => setSignedIn(false)} title="Sign out">
                  <Icon name="signOut" size={14}/>
                </button>
              </>
            }
          />
        )}
        {activeCallOpen && (
          <header className="topbar" style={{background:'var(--ec-slate-900)', color:'white', borderColor:'var(--ec-slate-800)'}}>
            <button className="btn ghost icon" onClick={() => setActiveCallOpen(false)} style={{color:'rgba(255,255,255,0.85)'}}>
              <Icon name="back" size={16}/>
            </button>
            <h1 style={{color:'white'}}>Active call</h1>
            <span className="pill" style={{background:'rgba(255,255,255,0.1)', color:'rgba(255,255,255,0.85)', border:'none', marginLeft:8}}>
              <span className="dot green"/> Connected
            </span>
            <div className="topbar-spacer"/>
          </header>
        )}
        <div style={{flex:1, minHeight:0, overflow: activeCallOpen ? 'hidden' : 'auto'}}>
          {content}
        </div>
      </div>

      {showIncoming && (
        <IncomingCall
          onAccept={() => { setShowIncoming(false); setActiveCallOpen(true); }}
          onDismiss={() => setShowIncoming(false)}
        />
      )}

      <TweaksPanel title="Tweaks">
        <TweakSection title="Appearance">
          <TweakRadio label="Theme" options={[{value:'light',label:'Light'},{value:'dark',label:'Dark'}]} value={tweaks.theme} onChange={v => setTweak('theme', v)}/>
          <TweakRadio label="Density" options={[{value:'comfortable',label:'Comfortable'},{value:'compact',label:'Compact'}]} value={tweaks.density} onChange={v => setTweak('density', v)}/>
          <TweakRadio label="Sidebar" options={[{value:'expanded',label:'Expanded'},{value:'collapsed',label:'Collapsed'}]} value={tweaks.rail} onChange={v => setTweak('rail', v)}/>
        </TweakSection>
        <TweakSection title="Demo">
          <TweakSelect
            label="Jump to screen"
            options={Object.keys(PAGE_TITLES).map(k => ({value:k, label: PAGE_TITLES[k][0]}))}
            value={page}
            onChange={(v) => { setActiveCallOpen(false); setPage(v); }}
          />
          <div style={{display:'flex', gap:6, flexDirection:'column'}}>
            <button className="btn sm" onClick={() => setActiveCallOpen(true)}>Open active-call screen</button>
            <button className="btn sm" onClick={() => setShowIncoming(true)}>Simulate incoming call</button>
            <button className="btn sm" onClick={() => setSignedIn(false)}>Show sign-in</button>
          </div>
        </TweakSection>
      </TweaksPanel>
    </div>
  );
};

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
