/* global React, Icon, UI, SAMPLE */
const { useState: useS4 } = React;

// === Messages page (unified SMS + Team chat) ===
const MessagesPage = () => {
  const [tab, setTab] = useS4('sms');
  const [sel, setSel] = useS4(SAMPLE.SMS_THREADS[0].id);
  const list = tab === 'sms' ? SAMPLE.SMS_THREADS : SAMPLE.TEAM_CHANNELS;
  const cur = list.find(x => x.id === sel) || list[0];

  return (
    <div className="content">
      <div className="list-pane">
        <div className="list-head">
          <div style={{display:'flex', alignItems:'center', marginBottom:10}}>
            <div style={{fontWeight:600, fontSize:14}}>Messages</div>
            <div className="spacer"/>
            <button className="btn primary sm"><Icon name="add" size={12}/> New</button>
          </div>
          <div className="search-wrap">
            <Icon name="search" size={14}/>
            <input className="search" placeholder="Search messages" style={{width:'100%'}}/>
          </div>
        </div>
        <div className="list-tabs" style={{paddingLeft:8}}>
          <button className={"list-tab " + (tab==='sms'?'active':'')} onClick={() => { setTab('sms'); setSel(SAMPLE.SMS_THREADS[0].id); }}>
            SMS <span className="soft mono" style={{fontSize:10}}>{SAMPLE.SMS_THREADS.reduce((a,t) => a + t.unread, 0)}</span>
          </button>
          <button className={"list-tab " + (tab==='team'?'active':'')} onClick={() => { setTab('team'); setSel(SAMPLE.TEAM_CHANNELS[0].id); }}>
            Team chat <span className="soft mono" style={{fontSize:10}}>{SAMPLE.TEAM_CHANNELS.reduce((a,t) => a + t.unread, 0)}</span>
          </button>
        </div>
        <div className="list-items">
          {list.map(t => (
            <div key={t.id} className={"list-item" + (t.id===sel?' selected':'')} onClick={() => setSel(t.id)}>
              {t.kind === 'channel' ? (
                <div className="av tone-3"><Icon name="hash" size={14}/></div>
              ) : (
                <div className={"av " + UI.toneFor(t.name)}>{UI.initials(t.name === 'Unknown' ? '?' : t.name.replace(/[+\d]/g, '#'))}</div>
              )}
              <div style={{flex:1, minWidth:0}}>
                <div style={{display:'flex', gap:6}}>
                  <div style={{fontWeight: t.unread ? 700 : 500, fontSize:13.5, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap'}}>
                    {t.kind === 'channel' ? '#' + t.name : t.name}
                  </div>
                  <div className="spacer"/>
                  <div className="soft" style={{fontSize:11}}>{t.when}</div>
                </div>
                {t.kind === 'sms' && <div className="soft mono" style={{fontSize:11}}>via {t.via}</div>}
                {t.kind === 'channel' && <div className="soft" style={{fontSize:11}}>{t.members} members</div>}
                <div style={{display:'flex', gap:6, marginTop:3}}>
                  <div className="soft" style={{fontSize:12.5, flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap'}}>{t.preview}</div>
                  {t.unread > 0 && <span className="nav-badge" style={{padding:'1px 6px', fontSize:10}}>{t.unread}</span>}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="detail-pane" style={{display:'flex', flexDirection:'column'}}>
        {cur && (
          <>
            <div style={{padding:'14px 20px', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', gap:12, background:'var(--surface)'}}>
              {cur.kind === 'channel'
                ? <div className="av tone-3"><Icon name="hash" size={14}/></div>
                : <div className={"av " + UI.toneFor(cur.name)}>{UI.initials(cur.name.replace(/[+\d]/g, '#'))}</div>}
              <div style={{flex:1}}>
                <div style={{fontWeight:600, fontSize:14}}>{cur.kind === 'channel' ? '#' + cur.name : cur.name}</div>
                <div className="soft" style={{fontSize:12}}>
                  {cur.kind === 'channel' ? `${cur.members} members` : `${cur.num} · texting via ${cur.via}`}
                </div>
              </div>
              <button className="btn"><Icon name="phone" size={14}/> Call</button>
              <button className="btn ghost icon"><Icon name="user" size={16}/></button>
              <button className="btn ghost icon"><Icon name="more" size={16}/></button>
            </div>
            <div style={{flex:1, overflow:'auto', padding:'20px 24px', display:'flex', flexDirection:'column', gap:10, background:'var(--bg)'}}>
              <div style={{textAlign:'center', fontSize:11, color:'var(--text-soft)', margin:'8px 0'}}>Today · {cur.kind === 'sms' ? 'SMS' : 'Team channel'}</div>
              {SAMPLE.MESSAGES.map(m => (
                <div key={m.id} style={{display:'flex', justifyContent: m.from === 'me' ? 'flex-end' : 'flex-start'}}>
                  <div style={{maxWidth: '70%'}}>
                    <div style={{
                      padding:'10px 14px',
                      borderRadius: m.from === 'me' ? '16px 16px 4px 16px' : '16px 16px 16px 4px',
                      background: m.from === 'me' ? 'var(--ec-orange)' : 'var(--surface)',
                      color: m.from === 'me' ? 'white' : 'var(--text)',
                      border: m.from === 'me' ? 'none' : '1px solid var(--border)',
                      fontSize: 13.5, lineHeight: 1.5,
                    }}>{m.text}</div>
                    <div className="soft" style={{fontSize:10.5, marginTop:3, textAlign: m.from === 'me' ? 'right' : 'left'}}>{m.t}</div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{padding:'12px 20px', borderTop:'1px solid var(--border)', background:'var(--surface)'}}>
              <div style={{display:'flex', alignItems:'center', gap:8, background:'var(--surface-2)', border:'1px solid var(--border)', borderRadius:12, padding:'8px 10px'}}>
                <button className="btn ghost icon sm"><Icon name="attach" size={14}/></button>
                <input className="input" style={{border:'none', background:'transparent', flex:1, padding:'4px 0'}} placeholder={cur.kind === 'channel' ? 'Message #' + cur.name : 'Reply via SMS…'}/>
                <button className="btn ghost icon sm"><Icon name="smile" size={14}/></button>
                <button className="btn primary sm"><Icon name="send" size={12}/> Send</button>
              </div>
              {cur.kind === 'sms' && (
                <div className="soft" style={{fontSize:11, marginTop:6, display:'flex', alignItems:'center', gap:6}}>
                  <Icon name="shield" size={11}/> Sending from <strong>{cur.via}</strong> · A2P 10DLC verified
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

// === Contacts ===
const ContactsPage = () => {
  const [sel, setSel] = useS4(SAMPLE.CONTACTS[0].id);
  const c = SAMPLE.CONTACTS.find(x => x.id === sel);
  const grouped = SAMPLE.CONTACTS.reduce((acc, c) => {
    const k = c.name[0].toUpperCase();
    (acc[k] = acc[k] || []).push(c);
    return acc;
  }, {});
  return (
    <div className="content">
      <div className="list-pane">
        <div className="list-head">
          <div style={{display:'flex', alignItems:'center', marginBottom:10}}>
            <div style={{fontWeight:600, fontSize:14}}>Contacts</div>
            <span className="soft mono" style={{fontSize:11, marginLeft:6}}>{SAMPLE.CONTACTS.length}</span>
            <div className="spacer"/>
            <button className="btn primary sm"><Icon name="add" size={12}/> Add</button>
          </div>
          <div className="search-wrap">
            <Icon name="search" size={14}/>
            <input className="search" placeholder="Search contacts" style={{width:'100%'}}/>
          </div>
        </div>
        <div className="list-tabs" style={{paddingLeft:8}}>
          <button className="list-tab active">All</button>
          <button className="list-tab">Starred</button>
          <button className="list-tab">Drivers</button>
          <button className="list-tab">Brokers</button>
          <button className="list-tab">Internal</button>
        </div>
        <div className="list-items">
          {Object.keys(grouped).sort().map(letter => (
            <div key={letter}>
              <div style={{padding:'6px 16px', fontSize:11, fontWeight:600, color:'var(--text-soft)', background:'var(--surface-2)', letterSpacing:'0.06em'}}>{letter}</div>
              {grouped[letter].map(c2 => (
                <div key={c2.id} className={"list-item" + (c2.id===sel?' selected':'')} onClick={() => setSel(c2.id)} style={{padding:'10px 16px'}}>
                  <div className={"av sm " + UI.toneFor(c2.name)}>{UI.initials(c2.name)}</div>
                  <div style={{flex:1, minWidth:0}}>
                    <div style={{display:'flex', alignItems:'center', gap:6}}>
                      <div style={{fontWeight:500, fontSize:13}}>{c2.name}</div>
                      {c2.starred && <Icon name="star" size={11} style={{color:'var(--amber)', fill:'var(--amber)'}}/>}
                    </div>
                    <div className="soft" style={{fontSize:11.5}}>{c2.role} · {c2.org}</div>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
      <div className="detail-pane">
        {c && (
          <div className="page" style={{maxWidth:840}}>
            <div className="page-head" style={{alignItems:'center'}}>
              <div className={"av xl " + UI.toneFor(c.name)}>{UI.initials(c.name)}</div>
              <div style={{flex:1}}>
                <h2 className="page-title">{c.name} {c.starred && <Icon name="star" size={16} style={{color:'var(--amber)', fill:'var(--amber)', verticalAlign:'-2px'}}/>}</h2>
                <div className="page-sub">{c.role} · {c.org}</div>
                <div style={{display:'flex', gap:6, marginTop:8}}>
                  {c.tags.map(t => <span key={t} className="pill slate">{t}</span>)}
                </div>
              </div>
              <button className="btn primary"><Icon name="phone" size={14}/> Call</button>
              <button className="btn"><Icon name="message" size={14}/> Message</button>
              <button className="btn ghost icon"><Icon name="edit" size={16}/></button>
              <button className="btn ghost icon"><Icon name="more" size={16}/></button>
            </div>
            <div className="grid" style={{gridTemplateColumns:'1fr 1fr'}}>
              <div className="card">
                <div className="card-head"><div className="card-title">Contact info</div></div>
                <div className="card-body col" style={{gap:12}}>
                  <KVRow2 k="Mobile" v={c.phone} mono/>
                  <KVRow2 k="Email" v={c.email}/>
                  <KVRow2 k="Organization" v={c.org}/>
                  <KVRow2 k="Role" v={c.role}/>
                  <KVRow2 k="Time zone" v="America/New_York · 3:42 PM"/>
                </div>
              </div>
              <div className="card">
                <div className="card-head"><div className="card-title">Linked accounts</div></div>
                <div className="card-body col" style={{gap:10}}>
                  <div className="row"><Icon name="external" size={13}/><span style={{fontSize:13}}>Salesforce contact</span><div className="spacer"/><span className="pill green"><span className="dot green"/> Linked</span></div>
                  <div className="row"><Icon name="external" size={13}/><span style={{fontSize:13}}>HubSpot lead</span><div className="spacer"/><span className="pill slate">Not linked</span></div>
                  <div className="row"><Icon name="external" size={13}/><span style={{fontSize:13}}>Samsara driver</span><div className="spacer"/><span className="pill green"><span className="dot green"/> Linked</span></div>
                </div>
              </div>
              <div className="card" style={{gridColumn:'1 / -1'}}>
                <div className="card-head"><div className="card-title">Recent activity</div><div className="spacer"/><button className="btn ghost sm">View all</button></div>
                <div>
                  {SAMPLE.CALLS.slice(0, 4).map(call => (
                    <div key={call.id} style={{display:'flex', alignItems:'center', gap:12, padding:'12px 16px', borderBottom:'1px solid var(--border)'}}>
                      <Icon name={call.dir === 'in' ? 'phoneIn' : 'phoneOut'} size={14} style={{color: call.dir === 'in' ? 'var(--green)' : 'var(--text-muted)'}}/>
                      <div style={{flex:1}}>
                        <div style={{fontSize:13, fontWeight:500}}>{call.dir === 'in' ? 'Inbound call' : 'Outbound call'} · {call.dur}</div>
                        <div className="soft" style={{fontSize:11.5}}>via {call.via}</div>
                      </div>
                      <div className="soft" style={{fontSize:11.5}}>{call.when}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const KVRow2 = ({ k, v, mono }) => (
  <div style={{display:'flex'}}>
    <div className="soft" style={{fontSize:12, width:120}}>{k}</div>
    <div className={mono ? 'mono' : ''} style={{fontSize:13, fontWeight:500}}>{v}</div>
  </div>
);

window.PageMessages = MessagesPage;
window.PageContacts = ContactsPage;
