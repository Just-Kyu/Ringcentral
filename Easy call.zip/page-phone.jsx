/* global React, Icon, UI, SAMPLE */
const { useState: useS1 } = React;

const dirIconA = (c) => c.status === 'missed' ? 'phoneMissed' : c.dir === 'in' ? 'phoneIn' : 'phoneOut';
const dirColorA = (c) => c.status === 'missed' ? 'var(--red)' : c.dir === 'in' ? 'var(--green)' : 'var(--text-muted)';

// === Phone panel — light, app-themed ===
const PhonePanel = () => {
  const [tab, setTab] = useS1('keypad');
  const [num, setNum] = useS1('');
  const [from, setFrom] = useS1(SAMPLE.NUMBERS[0].id);
  const [notesOn, setNotesOn] = useS1(true);
  const [showCallerPicker, setShowCallerPicker] = useS1(false);

  const press = (k) => setNum(n => n + k);
  const back = () => setNum(n => n.slice(0, -1));
  const fromNum = SAMPLE.NUMBERS.find(n => n.id === from);

  const keys = [
    {k:'1',s:''},{k:'2',s:'ABC'},{k:'3',s:'DEF'},
    {k:'4',s:'GHI'},{k:'5',s:'JKL'},{k:'6',s:'MNO'},
    {k:'7',s:'PQRS'},{k:'8',s:'TUV'},{k:'9',s:'WXYZ'},
    {k:'*',s:''},{k:'0',s:'+'},{k:'#',s:''},
  ];

  const TABS = [
    { id: 'keypad',    label: 'Keypad',    icon: null },
    { id: 'calls',     label: 'Calls',     icon: null },
    { id: 'voicemail', label: 'Voicemail', icon: null },
    { id: 'notes',     label: 'Notes',     icon: 'sparkle' },
  ];

  return (
    <div style={{
      display:'flex', justifyContent:'center', alignItems:'flex-start',
      padding: '32px 24px', minHeight: '100%', gap: 28, flexWrap:'wrap',
    }}>
      {/* Phone shell — light themed */}
      <div style={{
        width: 340,
        background: 'var(--surface)',
        borderRadius: 18,
        boxShadow: 'var(--shadow-lg)',
        overflow: 'hidden',
        color: 'var(--text)',
        display: 'flex', flexDirection: 'column',
        border: '1px solid var(--border)',
      }}>
        {/* Tabs */}
        <div style={{
          display:'flex', alignItems:'center',
          borderBottom: '1px solid var(--border)',
          padding: '0 6px',
          background: 'var(--surface-2)',
        }}>
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              flex: 1, background: 'transparent', border: 'none',
              color: tab === t.id ? 'var(--ec-orange-600)' : 'var(--text-muted)',
              fontWeight: tab === t.id ? 600 : 500,
              fontSize: 12.5, padding: '14px 4px 12px',
              borderBottom: '2px solid ' + (tab === t.id ? 'var(--ec-orange)' : 'transparent'),
              marginBottom: -1, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4,
            }}>
              {t.icon && <Icon name={t.icon} size={11}/>}
              {t.label}
            </button>
          ))}
        </div>

        {tab === 'keypad' && (
          <KeypadView
            num={num} press={press} back={back} keys={keys}
            fromNum={fromNum} from={from} setFrom={setFrom}
            showCallerPicker={showCallerPicker} setShowCallerPicker={setShowCallerPicker}
            notesOn={notesOn} setNotesOn={setNotesOn}
          />
        )}
        {tab === 'calls'     && <CallsView/>}
        {tab === 'voicemail' && <VoicemailView/>}
        {tab === 'notes'     && <NotesView notesOn={notesOn} setNotesOn={setNotesOn}/>}
      </div>

      {/* Side panels */}
      <div style={{maxWidth: 380, flex: '0 1 380px', display:'flex', flexDirection:'column', gap: 14}}>
        <div className="card">
          <div className="card-head">
            <Icon name="history" size={14}/>
            <div className="card-title">Recent activity</div>
            <div className="spacer"/>
            <button className="btn ghost sm">View all</button>
          </div>
          <div>
            {SAMPLE.CALLS.slice(0, 5).map(c => (
              <div key={c.id} style={{display:'flex', alignItems:'center', gap:10, padding:'10px 14px', borderBottom:'1px solid var(--border)'}}>
                <div style={{color: dirColorA(c)}}>
                  <Icon name={dirIconA(c)} size={13}/>
                </div>
                <div style={{flex:1, minWidth:0}}>
                  <div style={{fontWeight:500, fontSize:13}}>{c.to}</div>
                  <div className="soft mono" style={{fontSize:11}}>{c.num} · via {c.via}</div>
                </div>
                <div className="soft" style={{fontSize:11}}>{c.when}</div>
                <button className="btn ghost icon" style={{width:26, height:26}}><Icon name="phone" size={12}/></button>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <Icon name="star" size={14}/>
            <div className="card-title">Speed dial</div>
          </div>
          <div className="card-body" style={{display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:8}}>
            {SAMPLE.CONTACTS.filter(c => c.starred).slice(0,6).map(c => (
              <button key={c.id} className="btn" style={{flexDirection:'column', padding:'12px 6px', height:'auto', gap:5}}>
                <div className={"av sm " + UI.toneFor(c.name)}>{UI.initials(c.name)}</div>
                <div style={{fontSize:11.5, fontWeight:500, textAlign:'center', lineHeight:1.2}}>{c.name.split(' ')[0]}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <Icon name="bolt" size={14}/>
            <div className="card-title">Quick actions</div>
          </div>
          <div className="card-body" style={{display:'flex', flexDirection:'column', gap:6}}>
            <button className="btn sm" style={{justifyContent:'flex-start'}}><Icon name="userPlus" size={12}/> Add to contacts</button>
            <button className="btn sm" style={{justifyContent:'flex-start'}}><Icon name="message" size={12}/> Send SMS</button>
            <button className="btn sm" style={{justifyContent:'flex-start'}}><Icon name="calendar" size={12}/> Schedule callback</button>
          </div>
        </div>
      </div>
    </div>
  );
};

const KeypadView = ({ num, press, back, keys, fromNum, from, setFrom, showCallerPicker, setShowCallerPicker, notesOn, setNotesOn }) => (
  <div style={{padding:'20px 22px 24px', display:'flex', flexDirection:'column', alignItems:'center', position:'relative'}}>
    <button
      onClick={() => setShowCallerPicker(s => !s)}
      style={{
        background:'var(--ec-orange-50)', border:'1px solid var(--ec-orange-100)',
        color:'var(--text-muted)', fontSize: 12.5,
        display:'flex', alignItems:'center', gap:6, cursor:'pointer',
        padding: '6px 12px', borderRadius: 999,
      }}>
      <span>Caller ID:</span>
      <span style={{color:'var(--ec-orange-600)', fontWeight:600, fontFamily:'var(--font-mono)'}}>
        {fromNum?.number.replace('+1 ', '')}
      </span>
      <Icon name="chevDown" size={11}/>
    </button>

    {showCallerPicker && (
      <div style={{
        position:'absolute', top: 56, left: 22, right: 22,
        background:'var(--surface)', borderRadius: 10, boxShadow:'var(--shadow-lg)',
        zIndex: 5, padding: 6, border: '1px solid var(--border)',
      }}>
        {SAMPLE.NUMBERS.filter(n => n.status === 'active').slice(0, 5).map(n => (
          <button key={n.id} onClick={() => { setFrom(n.id); setShowCallerPicker(false); }} style={{
            width:'100%', textAlign:'left', padding:'8px 10px', borderRadius:6,
            background: n.id === from ? 'var(--ec-orange-50)' : 'transparent',
            border:'none', cursor:'pointer',
            display:'flex', flexDirection:'column', gap:2,
          }}>
            <div style={{fontSize:12, fontFamily:'var(--font-mono)', color: n.id === from ? 'var(--ec-orange-600)' : 'var(--text)', fontWeight:500}}>{n.number}</div>
            <div style={{fontSize:10.5, color:'var(--text-soft)'}}>{n.label} · {n.account}</div>
          </button>
        ))}
      </div>
    )}

    <div style={{
      width:'100%', textAlign:'center', margin: '14px 0 6px',
      minHeight: 44, display:'flex', alignItems:'center', justifyContent:'center',
      position:'relative',
    }}>
      <div style={{
        fontSize: num ? 28 : 17,
        fontFamily: num ? 'var(--font-mono)' : 'var(--font-ui)',
        color: num ? 'var(--text)' : 'var(--text-soft)',
        fontWeight: num ? 500 : 400,
        letterSpacing: num ? '0.04em' : 0,
      }}>{num || 'Enter a name or number'}</div>
      {num && (
        <button onClick={back} style={{
          position:'absolute', right: 0, top:'50%', transform:'translateY(-50%)',
          background:'transparent', border:'none', color:'var(--text-muted)', cursor:'pointer', padding: 6,
        }}><Icon name="back" size={16}/></button>
      )}
    </div>

    <div style={{display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:'6px 12px', width:'100%', margin:'8px 0 18px'}}>
      {keys.map(({k, s}) => (
        <button key={k} onClick={() => press(k)} style={{
          background:'transparent', border:'none', color:'var(--text)', cursor:'pointer',
          padding: '12px 0',
          display:'flex', flexDirection:'column', alignItems:'center', gap: 1,
          borderRadius: 999, transition: 'background 0.12s',
        }}
        onMouseEnter={e => e.currentTarget.style.background='var(--surface-2)'}
        onMouseLeave={e => e.currentTarget.style.background='transparent'}>
          <div style={{fontSize: 28, fontWeight: 400, letterSpacing:'0.02em', lineHeight: 1}}>{k}</div>
          <div style={{fontSize: 9, letterSpacing:'0.16em', color:'var(--text-soft)', minHeight: 11, fontWeight:500}}>{s || '\u00A0'}</div>
        </button>
      ))}
    </div>

    <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', width:'100%', padding: '0 18px'}}>
      <button onClick={() => setNotesOn(v => !v)} style={{
        background:'transparent', border:'none', cursor:'pointer',
        display:'flex', flexDirection:'column', alignItems:'center', gap: 4,
        color: 'var(--text-muted)',
      }}>
        <div style={{
          width: 44, height: 44, borderRadius: 12,
          background: notesOn ? 'var(--ec-orange-50)' : 'var(--surface-2)',
          color: notesOn ? 'var(--ec-orange-600)' : 'var(--text-muted)',
          display:'grid', placeItems:'center',
          border: '1px solid ' + (notesOn ? 'var(--ec-orange-100)' : 'var(--border)'),
        }}><Icon name="edit" size={16}/></div>
        <span style={{fontSize:10.5}}>Notes {notesOn ? 'on' : 'off'}</span>
      </button>

      <button style={{
        width: 64, height: 64, borderRadius: '50%',
        background: 'var(--ec-orange)', border: 'none', color: 'white', cursor: 'pointer',
        display: 'grid', placeItems: 'center',
        boxShadow: '0 8px 22px rgba(242,92,31,0.4), 0 1px 0 rgba(255,255,255,0.3) inset',
      }}><Icon name="phone" size={24} strokeWidth={2}/></button>

      <button style={{
        background:'transparent', border:'none', cursor:'pointer',
        display:'flex', flexDirection:'column', alignItems:'center', gap: 4,
        color: 'var(--text-muted)',
      }}>
        <div style={{
          width: 44, height: 44, borderRadius: 12,
          background: 'var(--surface-2)', display:'grid', placeItems:'center',
          border:'1px solid var(--border)', color: 'var(--text-muted)',
        }}><Icon name="userPlus" size={16}/></div>
        <span style={{fontSize:10.5}}>Add</span>
      </button>
    </div>
  </div>
);

const CallsView = () => (
  <div style={{maxHeight: 580, overflowY:'auto'}}>
    {SAMPLE.CALLS.slice(0, 10).map(c => (
      <div key={c.id} style={{
        display:'flex', alignItems:'center', gap:10, padding:'12px 16px',
        borderBottom:'1px solid var(--border)', cursor:'pointer',
      }}>
        <div className={"av sm " + UI.toneFor(c.to)}>{UI.initials(c.to === 'Unknown' ? '?' : c.to)}</div>
        <div style={{flex:1, minWidth:0}}>
          <div style={{display:'flex', alignItems:'baseline'}}>
            <div style={{
              fontSize: 13, fontWeight: 500,
              color: c.status === 'missed' ? 'var(--red)' : 'var(--text)',
              overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap',
            }}>{c.to}</div>
            <div style={{flex:1}}/>
            <div className="soft" style={{fontSize: 10.5}}>{c.when}</div>
          </div>
          <div style={{display:'flex', alignItems:'center', gap:5, marginTop:2}}>
            <Icon name={dirIconA(c)} size={10} style={{color: dirColorA(c)}}/>
            <span className="soft mono" style={{fontSize:11}}>{c.num}</span>
          </div>
        </div>
        <button style={{
          background:'var(--ec-orange-50)', border:'none', color:'var(--ec-orange-600)', cursor:'pointer',
          width:30, height:30, borderRadius:'50%', display:'grid', placeItems:'center',
        }}><Icon name="phone" size={13}/></button>
      </div>
    ))}
  </div>
);

const VoicemailView = () => (
  <div style={{maxHeight: 580, overflowY:'auto'}}>
    {SAMPLE.VOICEMAILS.map(v => (
      <div key={v.id} style={{padding:'12px 16px', borderBottom:'1px solid var(--border)'}}>
        <div style={{display:'flex', alignItems:'center', gap:10}}>
          <div style={{position:'relative'}}>
            <div className={"av sm " + UI.toneFor(v.from)}>{UI.initials(v.from === 'Unknown' ? '?' : v.from)}</div>
            {!v.read && <div style={{position:'absolute', top:-2, right:-2, width:9, height:9, borderRadius:'50%', background:'var(--ec-orange)', border:'2px solid var(--surface)'}}/>}
          </div>
          <div style={{flex:1, minWidth:0}}>
            <div style={{display:'flex', alignItems:'baseline'}}>
              <div style={{fontSize:13, fontWeight: v.read ? 500 : 700}}>{v.from}</div>
              <div style={{flex:1}}/>
              <div className="soft mono" style={{fontSize:10.5}}>{v.dur}</div>
            </div>
            <div className="soft mono" style={{fontSize:11, marginTop:1}}>{v.num}</div>
          </div>
        </div>
        <div className="muted" style={{
          fontSize: 12, marginTop: 8, lineHeight: 1.45,
          overflow:'hidden', display:'-webkit-box', WebkitLineClamp:2, WebkitBoxOrient:'vertical',
        }}>{v.transcript}</div>
        <div style={{display:'flex', gap:6, marginTop:10}}>
          <button className="btn sm" style={{flex:1}}><Icon name="play" size={11}/> Play</button>
          <button className="btn sm primary" style={{flex:1}}><Icon name="phone" size={11}/> Call back</button>
        </div>
      </div>
    ))}
  </div>
);

const NotesView = ({ notesOn, setNotesOn }) => (
  <div style={{padding: 18}}>
    <div style={{
      display:'inline-flex', alignItems:'center', gap:6,
      padding:'4px 10px', background:'var(--ec-orange-50)', color:'var(--ec-orange-600)',
      borderRadius: 999, fontSize: 11, fontWeight: 500, marginBottom: 12,
    }}><Icon name="sparkle" size={11}/> AI-assisted call notes</div>
    <div className="muted" style={{fontSize:12, marginBottom: 14, lineHeight: 1.5}}>
      When Notes is on, Easy Call silently transcribes your call, then saves a summary, action items, and key contact details into your CRM after you hang up.
    </div>
    <div style={{display:'flex', flexDirection:'column', gap:10}}>
      {[
        ['Auto-summarize',  'Action items + decisions',     true],
        ['Push to CRM',     'Salesforce, HubSpot',          true],
        ['Email recap',     'Sent to you and the contact',  false],
        ['Detect spam',     'Skip notes for likely spam',   true],
      ].map(([t, d, on]) => (
        <div key={t} style={{
          display:'flex', alignItems:'center', gap:10,
          padding:'10px 12px', background:'var(--surface-2)', borderRadius:8,
          border:'1px solid var(--border)',
        }}>
          <div style={{flex:1, minWidth:0}}>
            <div style={{fontSize:12.5, fontWeight:500}}>{t}</div>
            <div className="soft" style={{fontSize:11}}>{d}</div>
          </div>
          <div style={{
            width: 30, height: 18, borderRadius: 9,
            background: on ? 'var(--ec-orange)' : 'var(--surface-3)',
            position:'relative',
          }}>
            <div style={{
              width:14, height:14, borderRadius:'50%', background:'white',
              position:'absolute', top:2, left: on ? 14 : 2,
              boxShadow:'0 1px 2px rgba(0,0,0,0.2)',
            }}/>
          </div>
        </div>
      ))}
    </div>
  </div>
);

window.PagePhone = PhonePanel;
